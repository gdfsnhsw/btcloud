import copy
import json,time,re,os,sys,binascii,urllib
import core.include.public as public
import core.include.aes as aes
from core.include.monitor_exceptions import BtMonitorException
from core.include.monitor_helpers import monitor_events


"""
@name 授权主模块 
@author cjxin@bt.cn

"""

class main:
    __TRANSACTION_URL = 'http://www.example.com/api/v2/common_v1_authorization'
    __AUTH_URL = 'http://www.example.com/authorization'
    __AUTH_FILE = '{}/data/auth_info.json'.format(public.get_panel_path())
    __USER_PATH = '{}/data/user.json'.format(public.get_panel_path())
    __PLUGIN_NAME = 'cloud_monitor'
    __AUTH_RETRIES = 0
    __AUTH_NEXT_RETRY_TIME = 0

    def __init__(self):
        """
        @name 授权模块初始化
        """
        self.__PDATA = {}
        self.__USER_INFO = self._get_user_info()

        rdata = {}

        if self.__USER_INFO:
            rdata['secret_key'] = self.__USER_INFO['secret_key']
            self.__PDATA['access_key'] = self.__USER_INFO['access_key']
        else:
            rdata['secret_key'] = ''
            self.__PDATA['access_key'] = ''
        self.__PDATA['data'] = rdata
   
    #******************************************************* 授权模块对外接口start *********************************************************

    def get_token(self, get):
        """
        @name 获取官网登录token
        @author cjxin
        @get dict 请求参数
            username:用户名
            password:密码
            code:验证码
        """        
        data = {}
        data['username'] = get.get('username/s')
        data['password'] = public.md5(get.get('password/s',''))
        data['serverid'] = self._get_serverid()
        
        if 'code' in get: 
            data['code'] = get.get('code/xss')
        if 'token' in get: 
            data['token'] = get.get('token/xss')

        pdata = {}
        pdata['data'] = self._decode(data)

        try:
            rdata = public.httpPost(self.__AUTH_URL+'/login', pdata)
            rdata = json.loads(rdata)
            rdata['data'] = self._encode(rdata['data'])
            if not rdata['status']:
                return public.error(rdata['msg'])

            if rdata['data']:
                # print(rdata['data'])
                if rdata['data']['server_id'] != data['serverid']:
                    public.writeFile('data/sid.pl',rdata['data']['server_id'])
                public.writeFile(self.__USER_PATH, json.dumps(rdata['data']))

                self._flush_auth_cache(True)
        except:
            self._write_error_log(rdata +"\n" + public.get_error_info())
            return public.error('连接服务器失败')

        # 触发堡塔账号绑定成功事件
        public.event(monitor_events.AccountBoundSuccess())

        return public.success('绑定成功')

    def del_token(self, get):
        """
        @name 删除绑定token
        @author cjxin
        @get dict 请求参数        
        """
        if os.path.exists(self.__USER_PATH): 
            os.remove(self.__USER_PATH)
        return public.success('解绑帐号成功.')

    def get_bind_code(self, get):
        """
        @name 获取验证码
        @author cjxin
        @get dict 请求参数
            username:用户名
            token:本次验证码的token
        """        
        if not hasattr(get,'username') or not hasattr(get,'token'): 
            return public.error('参数错误.')

        data = {}
        pdata = {}
        data['username'] = get.get('username/s')
        data['token'] = get.get('token/xss')        
        pdata['data'] = self._decode(data)
        try:
            rdata = public.httpPost(self.__AUTH_URL + '/get_bind_code',pdata)  
            result = json.loads(rdata);           
            return result
        except Exception as ex:
            self._write_error_log(rdata +"\n" + public.get_error_info())
            return public.error('连接服务器失败!')

    def get_userinfo(self, get):
        """
        @name 获取用户信息
        @author cjxin
        @get dict 请求参数        
        """        
        data = self.__USER_INFO
        if not data:
            data = self._get_user_info()   

        result = {'status':False,'msg':'请先绑定宝塔帐号'}           
        if not data:
            result['data'] = ''
        else:
            result['status'] = True
            result['msg'] = '获取成功'

            result['data'] = {}
            keys = ['username','address','serverid','addtime']            
            for key in keys:
                try:
                    if key in data: result['data'][key] = data[key]
                except:pass            
            result['data']['username'] = data['username'][0:3]+'****' + data['username'][-4:]            
        return result

    def get_unbound_list(self, get):
        """
        @name 获取未绑定授权
        @author cjxin
        @get dict 请求参数
        """
        self.__PDATA['data']['product'] = self.__PLUGIN_NAME
        self.__PDATA['data'] = self._decode(self.__PDATA['data'])

        # print(self.__PDATA)
        result = public.httpPost(self.__AUTH_URL + '/unbound_list', self.__PDATA)
        try :
            result = json.loads(result)
        except: 
            return public.return_data(False, result)

        if not result['status']:
            return public.error(result['msg'], result.get('err_no', 0))

        data = self._encode(result['data'])       
        return public.success(data)

    def bind(self, get):
        """
        @name 绑定授权
        @author cjxin
        @get dict 请求参数
        """
        authorization_id = get.get('id', None)

        if authorization_id is None:
            return public.error('缺少参数：id')

        pdata = {}
        pdata.update(self.__PDATA)

        if 'data' not in pdata:
            pdata['data'] = {}

        pdata['data'].update({
            'id': authorization_id,
            'serverid': self._get_serverid(),
        })
        pdata['data']['product'] = self.__PLUGIN_NAME
        pdata['data'] = self._decode(self.__PDATA['data'])

        result = public.httpPost(self.__AUTH_URL + '/bind', pdata)

        try :
            result = json.loads(result)
        except: 
            return public.return_data(False, result)

        if not result['status']:
            return public.error(result['msg'])

        # 检查数据格式
        self._encode(result['data'])

        # 保存授权信息
        public.writeFile(self.__AUTH_FILE, '{}.{}'.format(result['data'], self._sign_auth_info(result['data'])))

        return public.success('绑定成功')

    def flush_auth_list(self, get):
        '''
        @name 刷新授权
        @author cjxin
        '''
        force = get.get('force/d', 0)
        ret = self._flush_auth_cache(force)
        return ret

    def check_auth_status(self, get):
        """
        @name 检查是否购买权限
        @author cjxin
        @get dict 请求参数
        """
        ret = self.flush_auth_list(get)
        return ret

    def get_pricing(self, args):
        '''
            @name 获取价格列表
            @author Zhj<2022-10-27>
            @arg cycle<?integer> 授权周期数/年[可选]
            @return dict
        '''
        result = public.httpPost(self.__TRANSACTION_URL + '/get_pricing', {
            'product': 'cloud_monitor',
            # 'cycle': args.get('cycle', 1),
        })

        try:
            result = json.loads(result)
        except:
            return public.error(result)

        if not result['success']:
            return public.error(result['res'])

        return public.success(result['res'])

    def create_order(self, args):
        '''
            @name 下单购买授权
            @author Zhj<2022-10-27>
            @arg cycle<?integer>    授权周期数/年[可选]
            @arg clients<?integer>  客户端数量[可选]
            @return dict
        '''
        # 用户未登录
        if self.__USER_INFO is None:
            return public.error('请先绑定堡塔账号')

        result = public.httpPost(self.__TRANSACTION_URL + '/create_by_user', {
            'uid': self.__USER_INFO.get('uid', 0),
            'server_id': self.__USER_INFO.get('server_id', ''),
            'src': 2,
            'product': 'cloud_monitor',
            'cycle': args.get('cycle', 1),
            'clients': args.get('clients', 1),
        })

        try:
            result = json.loads(result)
        except:
            return public.error(result)

        if not result['success']:
            return public.error(result['res'])

        return public.success(result['res'])

    def check_order_status(self, args):
        '''
            @name 检查支付状态
            @author Zhj<2022-10-27>
            @arg out_trade_no<string> 订单号
            @return dict
        '''
        result = public.httpPost('http://www.example.com/api/v2/order/product/detect', {
            'out_trade_no': args.get('out_trade_no', ''),
        })

        # print(result)

        try:
            result = json.loads(result)
        except:
            return public.error(result)

        if not result['success']:
            return public.error(result['res'])

        return public.success(result['res'])

    #******************************************************* 授权模块对外end *********************************************************

    def _write_error_log(self, msg):
        '''
        @name 写错误日志
        @author cjxin
        @msg string 错误信息
        '''
        public.writeFile('{}/logs/auth.error'.format(public.get_panel_path()),msg)

    def _flush_auth_cache(self, force=0):
        '''
        @name 刷新授权缓存
        @author cjxin
        '''
        # 每隔1天强制从云端同步授权信息
        if public.cache_get('BT_MONITOR_CACHE__LAST_AUTH_INFO_SYNC') is None:
            force = 1

        # 获取当前时间
        cur_time = int(time.time())

        # 默认授权信息
        auth_info = {
            'id': 0,
            'product': 'cloud_monitor',
            'status': 2,
            'clients': 5,
            'durations': 0,
            'end_time': int(time.time()) - 1,
            'type': 0,
            'cur_auth_num': 0,
        }

        # 获取当前授权数量
        cache_key = 'BT_MONITOR_CACHE__CUR_AUTH_NUM'

        cur_auth_num = public.cache_get(cache_key)

        if cur_auth_num is None:
            # 获取当前已授权的客户端数量
            with public.sqlite_easy('monitor_mgr') as db:
                cur_auth_num = db.query() \
                    .name('servers') \
                    .where('is_authorized=1') \
                    .where_in('status', [0, 1]) \
                    .count()

                # 缓存当前已授权的客户端数量2分钟
                public.cache_set(cache_key, cur_auth_num, 120)

        auth_info['cur_auth_num'] = cur_auth_num

        # 用户未登录
        if self.__USER_INFO is None:
            return public.success(auth_info)

        # 检查是否需要重试
        if self.__AUTH_NEXT_RETRY_TIME > 0 and self.__AUTH_NEXT_RETRY_TIME <= cur_time:
            force = 1

        try:
            if force or not os.path.exists(self.__AUTH_FILE):
                # 尝试获取授权ID
                if os.path.exists(self.__AUTH_FILE):
                    data = public.readFile(self.__AUTH_FILE)

                    if data:
                        # 获取授权密文与签名
                        parts = data.split('.', 1)

                        # 验证签名
                        if len(parts) > 1 and parts[1] == self._sign_auth_info(parts[0]):
                            data = self._encode(parts[0])
                            if isinstance(data, dict) and 'id' in data:
                                self.__PDATA['data']['id'] = data['id']

                self.__PDATA['data']['product'] = self.__PLUGIN_NAME
                self.__PDATA['data']['serverid'] = self._get_serverid()
                self.__PDATA['data'] = self._decode(self.__PDATA['data'])

                # TODO 这里需要考虑多次重试，尽可能减少网络问题对授权的影响
                # 最多重试5次：5分钟、10分钟、30分钟、1小时
                result = public.httpPost(self.__AUTH_URL + '/info', self.__PDATA)
                ok = True
                try:
                    result = json.loads(result)
                except:
                    ok = False

                if not ok or not result['status']:
                    ok = False

                    # 累计重试失败次数
                    self.__AUTH_RETRIES += 1

                    if self.__AUTH_RETRIES > 4:
                        self.__AUTH_RETRIES = 0
                        self.__AUTH_NEXT_RETRY_TIME = 0
                        raise BtMonitorException('flush auth info failed: {}'.format(result))

                    # 记录本次下一次重试时间，本次授权信息从本地读取
                    m = {
                        1: 5,
                        2: 10,
                        3: 30,
                        4: 60,
                    }

                    self.__AUTH_NEXT_RETRY_TIME = cur_time + m.get(self.__AUTH_RETRIES, 5)

                if ok:
                    # 缓存授权信息
                    public.writeFile(self.__AUTH_FILE, '{}.{}'.format(result['data'], self._sign_auth_info(result['data'])))

                # 标记本次授权信息同步成功
                public.cache_set('BT_MONITOR_CACHE__LAST_AUTH_INFO_SYNC', int(time.time()), 86400)

            # 尝试读取授权信息
            data = public.readFile(self.__AUTH_FILE)

            # 没有获取到授权信息时，初始化授权信息
            if not data:
                data = copy.deepcopy(auth_info)
                encoded_str = self._decode(data)
                public.writeFile(self.__AUTH_FILE, '{}.{}'.format(encoded_str, self._sign_auth_info(encoded_str)))

            # 获取授权密文与签名
            parts = data.split('.', 1)

            # 验证签名
            if len(parts) < 2 or parts[1] != self._sign_auth_info(parts[0]):
                raise BtMonitorException('flush auth info failed: 授权信息可能被篡改')

            data = self._encode(parts[0])

            # type 授权类型
            # 0-免费版
            # 1-专业版
            # 2-企业版
            auth_info['id'] = data['id']
            auth_info['product'] = data['product']
            auth_info['status'] = data['status']
            auth_info['clients'] += data['clients']
            auth_info['durations'] = data['durations']
            auth_info['end_time'] = data['end_time']

            if auth_info['id'] != 0:
                d = {
                    'cloud_monitor': 1,
                    'cloud_monitor_ltd': 2,
                }
                auth_info['type'] = d.get(auth_info['product'], 0)
        except BaseException as e:
            public.print_log(str(e))
            public.print_exc_stack(e)
        finally:
            # 当超出最大授权数量时，重置超出的主机授权状态
            self._slice_exceed_auth_num(int(auth_info.get('cur_auth_num', 0)), int(auth_info.get('clients', 0)))
            return public.success(auth_info)

    def _get_serverid(self, force=False):
        '''
        @name 获取服务器ID
        @author cjxin
        '''
        serverid_file = '{}/data/sid.pl'.format(public.get_panel_path())
        if os.path.exists(serverid_file) and not force:
            serverid = public.readFile(serverid_file)
            if re.match("^\w{64}$",serverid): return serverid
        s1 = self._get_mac_address() + self._get_hostname()
        s2 = self._get_hostname()
        serverid = public.md5(s1) + public.md5(s2)
        public.writeFile(serverid_file,serverid)
        return serverid

    def _get_mac_address(self):
        '''
        @name 获取MAC地址
        @author cjxin
        '''
        import uuid
        mac=uuid.UUID(int = uuid.getnode()).hex[-12:]
        return ":".join([mac[e:e+2] for e in range(0,11,2)])
    
    def _get_hostname(self):
        """
        @name 获取主机名
        @author cjxin
        """
        import socket
        return socket.getfqdn(socket.gethostname())

    def _get_user_info(self):
        """
        @name 获取用户信息
        """
        data = None
        try:
            if os.path.exists(self.__USER_PATH): 
                data = json.loads(public.readFile(self.__USER_PATH))
        except: pass
        return data

    #加密数据
    def _decode(self, data):
        """
        @name 加密数据
        @author cjxin
        @data dict 加密数据
        """
        if sys.version_info[0] == 2:
            pdata = urllib.urlencode(data)
        else:
            pdata = urllib.parse.urlencode(data)
            if type(pdata) == str: pdata = pdata.encode('utf-8')
        return binascii.hexlify(pdata).decode('utf-8')
    
    #解密数据
    def _encode(self, data):
        """
        @name 解密数据
        @author cjxin
        @data string 解密数据
        """
        if sys.version_info[0] == 2:
            result = urllib.unquote(binascii.unhexlify(data))
        else:
            if type(data) == str: data = data.encode('utf-8')
            tmp = binascii.unhexlify(data)
            if type(tmp) != str: tmp = tmp.decode('utf-8')
            result = urllib.parse.unquote(tmp)

        if type(result) != str: result = result.decode('utf-8')
        return json.loads(result)

    def _sign_auth_info(self, encrypted_auth_info):
        '''
            @name 对授权信息(密文)进行签名
            @author Zhj<2022-10-24>
            @param encrypted_auth_info:
            @return string
        '''
        return aes.aescrypt_py3('kv01kvasdoaksdkj', 'CBC', b'bvkf0ek0qwfovj92').aesencrypt(encrypted_auth_info)

    def _slice_exceed_auth_num(self, cur_auth_num, clients):
        '''
            @name 处理当前多出来的授权
            @author Zhj<2022-11-09>
            @param cur_auth_num<integer>    当前授权数
            @param clients<integer>         可授权数
            @return void
        '''
        if cur_auth_num <= clients:
            return

        sid_list = []

        # 按添加时间倒序排列，查询出当前超出的已授权主机
        with public.sqlite_easy('monitor_mgr') as db:
            sid_list = db.query()\
                .name('servers')\
                .where('is_authorized=1')\
                .order('create_time', 'desc')\
                .limit(999999999, clients)\
                .column('sid')

            # 关闭事务自动提交
            db.autocommit(False)

            # 更新授权状态
            db.query()\
                .name('servers')\
                .where_in('sid', sid_list)\
                .update({
                    'is_authorized': 0,
                    'status': 0,
                    'update_time': int(time.time()),
                })

            # 提交事务
            db.commit()

        # 缓存当前已授权的客户端数量2分钟
        public.cache_set('BT_MONITOR_CACHE__CUR_AUTH_NUM', clients, 120)
