import json,requests
import core.include.public as public
import core.include.c_loader.PluginLoader as plugin_loader


main = plugin_loader.get_module('{}/modules/msgModule/main.py'.format(public.get_panel_path())).main

# from modules.msgModule.main import main

"""
@name 钉钉消息通道模块 
@author cjxin@bt.cn
"""

class dingding(main):

    __info = None
    __msg_type = 'dingding'
    
    def __init__(self):   

        self.__info = self.get_config(None)

  
    def get_config(self,get = None):
        """
        @name 获取配置
        @author cjxin
        """
        return self._get_base_config(self.__msg_type)

    def set_config(self,get):
        """
        @name 设置配置
        @author cjxin
        """
        if not hasattr(get, 'url') or not hasattr(get, 'atall'): 
            return self._return_data(self.__msg_type, False, '配置失败，请填写完整信息!')
        import  re
        rule = re.compile(r'^https?://')
        if not re.match(rule, get.url):
            return self._return_data(self.__msg_type, False, '未正确配置信息。')

        data = {"dingding_url": get.get('url/s'), "isAtAll": True, "user":1 }
        return self._set_base_config(self.__msg_type,data)

    def is_configured(self):
        '''
            @name 检查钉钉是否配置
            @author Zhj<2022-08-02>
            @return bool
        '''
        if self.__info is None \
                or not isinstance(self.__info, dict) \
                or 'dingding_url' not in self.__info \
                or self.__info['dingding_url'] is None\
                or self.__info['dingding_url'] == '':
            return False

        return True

    def send_msg(self,minfo):
        """
        @name 发送消息
        @author cjxin
        @minfo dict  {
            msg:string(消息内容),
        }
        """
        if not self.__info :
             return self._return_data(self.__msg_type,False,'未正确配置信息。')

        data = {
            "msgtype": "markdown",
            "markdown": {
                "title": "服务器通知",
                "text": minfo['msg']
            },
            "at": {
                "atMobiles": [ self.__info['user'] ],
                "isAtAll": self.__info['isAtAll']
            }
        }
        headers = {'Content-Type': 'application/json'}
        try:
            x = requests.post(url = self.__info['dingding_url'], data=json.dumps(data), headers=headers,verify=False)            
            if x.json()["errcode"] == 0:             
                return self._return_data('通知方式:【钉钉】, 收件人:【所有人】',True,'消息发送成功:{}'.format(minfo['msg']))
            else:
                return self._return_data('通知方式:【钉钉】, 收件人:【所有人】',False,'消息发送失败:{}'.format(minfo['msg']),x.json()['errmsg'])
        except:
            return self._return_data('通知方式:【钉钉】, 收件人:【所有人】',False,'消息发送失败:{}'.format(minfo['msg']),public.get_error_info(), need_write_log=False)


  

