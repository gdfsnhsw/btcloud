import os, sys, time, re
import core.include.public as public

class main():
    '''
        @name crond定时任务类
    '''

    def __init__(self):
        # 每次实例化时检查crontab是否启动
        # 没有启动时，尝试重启
        if not self.crond_is_running():
            self.crond_restart()

    # 取任务构造Day
    def GetDay(self, param):
        cuonConfig = "{0} {1} * * * ".format(param['minute'], param['hour'])
        return cuonConfig

    # 取任务构造Day_n
    def GetDay_N(self, param):
        cuonConfig = "{0} {1} */{2} * * ".format(param['minute'], param['hour'], param['where1'])
        return cuonConfig

    # 取任务构造Hour
    def GetHour(self, param):
        cuonConfig = "{0} * * * * ".format(param['minute'])
        return cuonConfig

    # 取任务构造Hour-N
    def GetHour_N(self, param):
        cuonConfig = "{0} */{1} * * * ".format(param['minute'], param['where1'])
        return cuonConfig

    # 取任务构造Minute-N
    def Minute_N(self, param):
        cuonConfig = "*/{0} * * * * ".format(param['where1'])
        return cuonConfig

    # 取任务构造week
    def Week(self, param):
        cuonConfig = "{0} {1} * * {2}".format(param['minute'], param['hour'], param['week'])
        return cuonConfig

    # 取任务构造Month
    def Month(self, param):
        cuonConfig = "{0} {1} {2} * * ".format(param['minute'], param['hour'], param['where1'])
        return cuonConfig

    # 构造周期
    def get_crond_cycle(self, params):
        cuonConfig = ""
        if params['type'] == "day":
            cuonConfig = self.GetDay(params)
        elif params['type'] == "day-n":
            cuonConfig = self.GetDay_N(params)
        elif params['type'] == "hour":
            cuonConfig = self.GetHour(params)
        elif params['type'] == "hour-n":
            cuonConfig = self.GetHour_N(params)
        elif params['type'] == "minute-n":
            cuonConfig = self.Minute_N(params)
        elif params['type'] == "week":
            params['where1'] = params['week']
            cuonConfig = self.Week(params)
        elif params['type'] == "month":
            cuonConfig = self.Month(params)
        return cuonConfig, params

    # 获取计划任务文件位置
    def get_cron_file(self):
        u_path = '/var/spool/cron/crontabs'
        u_file = u_path + '/root'
        c_file = '/var/spool/cron/root'
        cron_path = c_file
        if not os.path.exists(u_path):
            cron_path = c_file

        if os.path.exists("/usr/bin/apt-get"):
            cron_path = u_file
        elif os.path.exists('/usr/bin/yum'):
            cron_path = c_file

        if cron_path == u_file:
            if not os.path.exists(u_path):
                os.makedirs(u_path, 472)
                public.ExecShell("chown root:crontab {}".format(u_path))
        return cron_path

    # 执行crontab相关命令
    def __crond_exec(self, opt):
        if os.path.exists('/etc/init.d/crond'):
            return public.ExecShell('/etc/init.d/crond {}'.format(opt))

        if os.path.exists('/etc/init.d/cron'):
            return public.ExecShell('service cron {}'.format(opt))

        return public.ExecShell("systemctl {} crond".format(opt))

    # 重载配置
    def crond_reload(self):
        self.__crond_exec('reload')

    # 重启服务
    def crond_restart(self):
        self.__crond_exec('restart')

        # 重新检测服务是否启动
        self.crond_is_running(True)

    # 检查服务是否运行
    def crond_is_running(self, force=False):
        cache_key = 'BT_MONITOR_CACHE__CROND_IS_RUNNING'

        flag = public.cache_get(cache_key)

        if not force and flag is not None:
            return flag

        flag = False

        res, _ = self.__crond_exec('status')

        if res and re.search(r'Active: active \(running\)', str(res)):
            flag = True

        public.cache_set(cache_key, flag, 600)

        return flag

    # 将Shell脚本写到文件
    def write_shell(self, config):
        u_file = '/var/spool/cron/crontabs/root'
        file = self.get_cron_file()
        if not os.path.exists(file): public.writeFile(file, '')
        conf = public.readFile(file)
        if type(conf) == bool: return public.returnMsg(False, '读取文件失败!')
        conf += config + "\n"
        if public.writeFile(file, conf):
            if not os.path.exists(u_file):
                public.ExecShell("chmod 600 '" + file + "' && chown root.root " + file)
            else:
                public.ExecShell("chmod 600 '" + file + "' && chown root.crontab " + file)
            return True
        return public.returnMsg(False, '文件写入失败,请检查是否具有足够的权限!')

    # 从crond删除
    def remove_for_crond(self, echo):
        file = self.get_cron_file()
        conf = public.readFile(file)
        if not conf or conf.find(str(echo)) == -1: return True
        rep = ".+" + str(echo) + ".+\n"
        conf = re.sub(rep, "", conf)
        try:
            if not public.writeFile(file, conf): return False
        except:
            return False
        self.crond_reload()
        return True

    def create_task(self, task_name, params={}):
        """创建任务"""
        task_path = "{}/crontab_tasks".format(public.get_panel_path())
        task_log = task_path + "/log.log"
        log_content = ''

        if os.path.exists(task_log):
            log_content = public.readFile(task_log)

        for _l in log_content.split("\n"):
            if _l.startswith(task_name + " "):
                # print("任务已存在。")
                return 2

        cron_time_str, params = self.get_crond_cycle(params)

        # 添加可执行权限
        public.ExecShell('chmod +x {}'.format('%s/%s.py' % (task_path, task_name)))

        cronConfig = cron_time_str + ' ' + task_path + '/' + task_name + '.py' + ' >> ' + task_path + '/' + task_name + '.log 2>&1'
        self.write_shell(cronConfig)
        if not log_content:
            log_content = ""
        else:
            log_content += "\n"
        log_line = task_name + " " + str(time.time())
        log_content += log_line
        public.writeFile(task_log, log_content)
        self.crond_reload()
        return 1

    def delete_task(self, task_name):
        """删除计划任务

        Args:
            task_name (str): 任务名称
        """
        if not self.remove_for_crond(task_name):
            return 0

        task_path = "{}/crontab_tasks".format(public.get_panel_path())
        task_log = task_path + "/log.log"
        log_content = ''

        if os.path.exists(task_log):
            log_content = public.readFile(task_log)

        if log_content == '':
            return 1

        new_logs = ""
        log_content = re.sub(r'^\s+$', '', log_content, flags=re.MULTILINE)
        for _l in log_content.split("\n"):
            if _l.startswith(task_name + " "):
                continue
            new_logs += _l + "\n"
        public.writeFile(task_log, new_logs)
        return 1