#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2019 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: hwliang <hwl@bt.cn>
# +-------------------------------------------------------------------
#
#             ┏┓      ┏┓
#            ┏┛┻━━━━━━┛┻┓
#            ┃               ☃           ┃
#            ┃  ┳┛   ┗┳ ┃
#            ┃     ┻    ┃
#            ┗━┓      ┏━┛
#              ┃      ┗━━━━━┓
#              ┃  神兽保佑     ┣┓
#              ┃ 永无BUG！     ┏┛
#              ┗┓┓┏━┳┓┏━━━━━┛
#               ┃┫┫ ┃┫┫
#               ┗┻┛ ┗┻┛

class pay:

    #获取用户信息
    def get_user_info(self,get):
        pass;

    #创建支付订单
    def create_pay_order(self,get):
        pass;

    #获取微信支付二维码
    def get_weixin_pay(self,get):
        pass;

    #获取支付宝支付订单
    def get_alipay_pay(self,get):
        pass

    #判断当前支付状态
    def check_pay_status(self,get):
        pass;

    #
