#!/usr/bin/python
#coding: utf-8
#-----------------------------
# 安装脚本
#-----------------------------

import sys,os,shutil
panelPath = os.getenv('BT_PANEL')
os.chdir(panelPath)
sys.path.append("class/")
import public,tarfile

class panel_pm2:
    _name = 'pm2'
    _version = None
    _setup_path = None

    __path = panelPath + '/plugin/' + _name
    __soft_path = None
    def __init__(self,name,version,setup_path): 
        self._version = version
        self._setup_path = setup_path
        self.__soft_path = setup_path + '/pm2'
    
    def install_soft(self,downurl):
        if not os.path.exists(self.__path): os.makedirs(self.__path)

        downUrl = public.get_url()
        pluginUrl = downUrl + '/win/install/plugin/' + self._name

        fileList = ['pm2_main.py','index.html','info.json','icon.png']
        for f in fileList:
            public.bt_print(pluginUrl + '/' + f)
            public.downloadFile(pluginUrl + '/' + f,self.__path + '/' + f)
            if not os.path.exists(self.__path + '/' + f):
                public.bt_print("ERROR:文件下载失败!")
                return public.returnMsg(False,'文件下载失败。');

        public.bt_print("pm2安装成功..")
        return public.returnMsg(True,'pm2安装成功。');

    def uninstall_soft(self):
        os.system("sc stop pm2")
        os.system("sc delete pm2")
        shutil.rmtree(self.__path)
        try:
            shutil.rmtree(self.__soft_path)
        except : pass

    def update_soft(self,downurl):
        self.install_soft(downurl)
        return public.returnMsg(True,'更新成功!');



