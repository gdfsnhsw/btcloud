var firewall = {
	event: function() {
	  var that = this, name = bt.get_cookie('firewall_type');
	  // 切换主菜单
	  $('#cutTab').on('click', '.tabs-item', function () {
		var index = $(this).index(), name = $(this).data('name')
		var parent = $(this).parent().parent().nextAll('.tab-view-box').children('.tab-con').eq(index)
		var parentData = parent.data('name')
		$(this).addClass('active').siblings().removeClass('active');
		parent.addClass('show w-full').removeClass('hide').siblings().removeClass('show w-full').addClass('hide');
		that[name].event();
		bt.set_cookie('firewall_type',name)
		switch (name){
			case 'safety':
			  that.safety.getFirewallIfo();
			  break;
		  }
	  })
	  $('[data-name="'+ (name || 'safety') +'"]').trigger('click')
	},
	// 系统防护墙
	safety:{
		over_port_list: [],
		over_ip_shielding_list: [],
		over_ip_white_list: [],
		/**
		 * @description 事件绑定
		 */
		event: function () {
		  var that = this;
		  bt.firewall.get_logs_size(logsPath,function(rdata){
			$("#logSize").text(rdata);
		  })
		  // 切换系统防火墙菜单事件
		  $('#safety').unbind('click').on('click', '.tab-nav-border span', function () {
			var index = $(this).index();
			$(this).addClass('on').siblings().removeClass('on');
			$(this).parent().next().find('.tab-block').eq(index).addClass('on').siblings().removeClass('on');
			$('.state-content').show().find('.safety-header').show().siblings().hide()
			that.cutFirewallTab(index);
		  })
		  $('#ssh_ping').unbind('click').on('click',function (){
			var _that = $(this), status = _that.prop("checked")?0:1;
			bt.firewall.ping(status,function(rdata){
			  if(rdata === -1){
				_that.prop('checked',!!status);
			  }else{
				bt.msg(rdata);
			  }
			})
		  })
		  bt.firewall.get_ssh_info(function(rdata){
			if(rdata.ping){
				$('#ssh_ping').removeAttr('checked');
			}else{
				$('#ssh_ping').attr('checked','checked');
			}
			})
		  $('#safety .tab-nav-border span').eq(0).trigger('click');
		},
		/**
		 * @description 清空日志
		 */
		clear_logs_files:function(){
		  bt.show_confirm('清空日志', '即将清空Web日志，是否继续？', function () {
			bt.firewall.clear_logs_files(function(rdata){
			  $("#logSize").text(rdata);
			  bt.msg({msg:lan.firewall.empty,icon:1});
			})
		  })
		},

		/**
		 * @description 切换系统防火墙菜单
		 * @param {number} index 索引
		 */
		cutFirewallTab: function (index) {
		  switch (index) {
			case 0:
			  this.portRuleTable('','',true)
			  break;
			case 1:
				this.portForwardTable()
			  break;
			case 2:
				this.ipRuleTable()
			  break;
			case 3:
				this.whiteipRuleTable()
			  break;
		  }
		},
		 /**
		 * @description 获取防火墙信息
		 */
		  getFirewallIfo:function () {
			// bt_tools.send({
			//   url: '/safe/firewall/get_firewall_info',
			// },function (rdata){
			// //   $('#isFirewall').prop("checked",rdata.status);
			// //   $('#ssh_ping').prop('checked',!rdata.ping);
			// //   $('#safety .tab-nav-border span:eq(0) > i').html(rdata.port)
			// //   $('#safety .tab-nav-border span:eq(1) > i').html(rdata.ip)
			// //   $('#safety .tab-nav-border span:eq(2) > i').html(rdata.trans)
			// //   $('#safety .tab-nav-border span:eq(3) > i').html(rdata.country)
			// },'获取系统防火墙状态')
		},
		/**
		 * @description 渲染系统防火墙端口规则
		 */
		portRuleTable: function (dir,search,isLoad) {
		  	var that = this,_url = '',ruleTable = null,loadT = null;
			  if(isLoad) loadT = bt.load('正在获取列表数据，请稍后...')
			$.post('/safe/firewalls/get_all_rules', {dir: dir ? dir : '',search: search ? search : ''}, function (res) {
				if(isLoad) loadT.close()
				var data = res['msg'] ? [] : res
				if(res['msg']) {
					$('.firewall-tab-view .warning_info').remove()
					$('.firewall-tab-view').prepend('<div class="warning_info mb10 "><p class="">温馨提示：'+ res.msg +'</p></div>')
				}
				that.over_port_list = data
				ruleTable = bt_tools.table({
					el: '#portRules',
					// url: '/safe/firewalls/get_all_rules',
					// param: {
					// 	dir: dir ? dir : ''
					// },
					load: '获取端口规则列表',
					default: '端口规则列表为空', // 数据为空时的默认提示
					height: $(window).height() - 400,
					data: data,
					// beforeRequest: 'model',
					// dataFilter: function (res) {
					// 	that.over_port_list = res
					// 	return { data: res };
					// },
					tootls: [
						{ // 按钮组
							type: 'group',
							positon: ['left', 'top'],
							list: [{
								title: '添加规则',
								active: true,
								event: function (ev,_that) {
									that.editPortRule(false,_that)
								}
							},
							// {
							// 	title: '导入规则',
							// 	event: function (ev,_that) {
							// 	  that.import_or_export_view('rule','import',_that)
							// 	}
							//   },
							   {
								title: '导出规则',
								event: function (ev,_that) {
									that.import_or_export_view('rule','export',_that)
								}
							}]
						}
						// ,{
						// 	type: 'search',
						// 	positon: ['right', 'top'],
						// 	placeholder: '请输入端口/备注',
						// 	searchParam: 'search', //搜索请求字段，默认为 search
						// 	value: search ? search : '',// 当前内容,默认为空
						// }
					],
					column: [
						{title: '端口', fid: 'port', width: 150},
						{title: '作用域',  width: 150,template:function(item){
							return '<span>' + (item['ip'] == 'all' ? '所有' : item['ip']) + '</span>'
						}},
						{title: '进/出方向', width: 100,template:function(item){
							return '<span>' + (item['dir'] == 'out' ? '出方向' : '进方向') + '</span>'
						}},
						{title: '协议', fid: 'protocol', width: 100},
						{title: '状态', width: 100,template:function(item){
							return (item['status'] ? '<a data-name='+ item.name +' data-status='+ (item.status ? 'no' : 'yes') +' class="btlink rule_status">已启用<span class="glyphicon glyphicon-play"></span></a>' : '<a class="rule_status" data-name='+ item.name +' data-status='+ (item.status ? 'no' : 'yes') +' href="javascript:;" style="color:red">已禁用<span class="glyphicon glyphicon-pause"></span></a>')
						}},
						{title: '备注', fid: 'name', width: 100},
						{title: '类型', width: 100,template:function(item){
							return (item['handle'] === 'allow' ? '<span style="color:#20a53a">放行</span>' : '<span style="color:red">拦截</span>')
						}},
						{
							title: '操作',
							type: 'group',
							width: 150,
							align: 'right',
							group: [{
								title: '编辑',
								event: function (row, index, ev, key, _that) {
									that.editPortRule(row,_that)
								}
							}, {
								title: '删除',
								event: function (row, index, ev, key, _that) {
									that.removePortRule(row,_that)
								}
							}]
						}
					],
					success: function (layero,indexs) {
						if(!$('#portRules [name=search_dir]').length){
							$('.search_input').val(search ? search : '')
							$('#portRules .tootls_top .pull-right').append('<select class="bt-input-text pull-right" name="search_dir" style="width:75px;margin-right:10px">'
								+ '<option value="all" selected="selected">所有</option>'
								+ '<option value="in">进方向</option>'
								+ '<option value="out">出方向</option>'
								+ '</select><div class="bt_search"><input type="text" class="search_input" style="" placeholder="请输入端口/备注"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></div>').css({'display':'flex'})
							$('#portRules [name=search_dir]').val(dir?dir:'all')
							$('#portRules [name=search_dir]').change(function () {
								that.portRuleTable($(this).val(),$('.search_input').val())
							})
							$('#portRules .search_input').keyup(function (e) {
								if (e.keyCode == 13) {
									that.portRuleTable($('#portRules [name=search_dir]').val(),$(this).val())
								}
							})
							$('#portRules .glyphicon-search').click(function () {
								that.portRuleTable($('#portRules [name=search_dir]').val(),$('#portRules .search_input').val())
							})
							$('#portRules').append('<ul class="help-info-text c7">\
								<li>作用域：此条规则所影响的范围（127.0.0.1,192.168.1.1/24），留空则所有IP都生效</li>\
							</ul>')
						}
						$('#portRules .rule_status').click(function () {
							bt_tools.send({ url: '/safe/firewall/set_rule_status', data:{data:JSON.stringify({ rule_name: $(this).data('name'), status: $(this).data('status') })}},function (rdata){
								bt.msg(rdata)
								if(rdata.status) ruleTable.$refresh_table_list(false)
							}, '设置端口规则状态')
						})
					}
				})
				return ruleTable
			})
		},
		// 判断备注是否重复
		is_name_repeat: function (name) {
			var _kk = true;
			this.each(this.over_port_list, function (ko, items) {
				if (items['name'].indexOf(name) != -1) {
					return _kk = false;
				}
			})
			return _kk
		},
		// 遍历数据
        each: function (obj, fn) {
            var key, that = this;
            if (typeof fn !== 'function') return that;
            obj = obj || [];
            if (obj.constructor === Object) {
                for (key in obj) {
                    if (fn.call(obj[key], key, obj[key])) break;
                }
            } else {
                for (key = 0; key < obj.length; key++) {
                    if (fn.call(obj[key], key, obj[key])) break;
                }
            }
            return that;
        },
		/**
		 * @description 添加/编辑端口规则
		 * @param {object} row 数据
		 */
		editPortRule: function (row,_table) {
		  var isEdit = !!row, that = this,port_form = null
		  row = row || []
		  if(isEdit) row['ip'] = row['ip'] === 'all'? '' : row['ip']
		  layer.open({
			type: 1,
			area:"400px",
			title: (!isEdit?'添加':'编辑') + '规则',
			closeBtn: 2,
			shift: 5,
			shadeClose: false,
			btn: ['提交','取消'],
			content: '<div class="ptb20" id="editPortRuleForm"></div>',
			yes:function(index,layers){
				var formValue = port_form.$get_form_value()
				if (formValue.name == '') return layer.msg('请输入备注', { icon: 2 })
				if (formValue.port == '') return layer.msg('请输入端口', { icon: 2 })
				if (!isEdit) {
					if (!that.is_name_repeat(formValue.name)) { return layer.msg('防火墙中已存在【' + formValue.name + '】规则，请勿重复添加.', { icon: 2 }) }
				}
				formValue['rule_name'] = formValue.name
				formValue['rule_action'] = formValue.type
				if (formValue.ip.trim() != '') formValue['remoteip'] = formValue.ip
				delete formValue['name']
				delete formValue['ip']
				delete formValue['type']
				bt_tools.send({ url: '/safe/firewall/'+ (isEdit ? 'set_rules' : 'add_rules'), data:formValue},function (rdata){
					bt.msg(rdata)
					if(rdata.status) {
						layer.close(index)
						that.portRuleTable($('#portRules [name=search_dir]').val(),$('#portRules .search_input').val())
					}
				}, (!isEdit?'添加':'编辑')+'端口规则')
			},
			success:function(layero,index){
				port_form = bt_tools.form({
					el:'#editPortRuleForm',
					form: [
						{
							label:'端口',
							group:{
								type:'text',
								name:'port',
								width:'245px',
								placeholder:'参考格式:888,3000-4000',
							}
						},{
							label:'出/入方向',
							group:{
								type:'select',
								name:'dir',
								width:'245px',
								list:[
									{title:'进方向',value:'in'},
									{title:'出方向',value:'out'}
								]
							}
						},{
							label:'协议',
							group:{
								type:'select',
								name:'protocol',
								width:'245px',
								list:[
									{title:'TCP',value:'TCP'},
									{title:'UDP',value:'UDP'}
								]
							}
						},{
							label:'类型',
							group:{
								type:'select',
								name:'type',
								width:'245px',
								list:[
									{title:'放行',value:'allow'},
									{title:'拦截',value:'block'}
								]
							}
						},{
							label:'备注',
							group:{
								type:'text',
								name:'name',
								width:'245px',
								placeholder:'请输入备注',
								disabled: isEdit ? true : false
							}
						},{
							label:'作用域',
							group:{
								type:'text',
								name:'ip',
								width:'245px',
								placeholder:'此项为空时，为不限制IP',
							}
						}],
					data:row ? row : []
				})
				$('#editPortRuleForm [name=port]').on('input',function () {
					var name = $('#editPortRuleForm [name=name]')
					if(isEdit && name.val() != '') return
					name.val($(this).val())
				})
			}
		  });
		},

		/**
		 * @description 删除端口规则
		 * @param {object} row 行数据
		 */
		removePortRule: function (row,_table){
		  var that = this;
		  layer.confirm('是否删除当前端口规则,是否继续？',{btn: ['确认','取消'],icon:3,closeBtn: 2,title:'删除规则'},function(index){
			layer.close(index);
			bt_tools.send({ url:'/safe/firewall/del_rules', data:{rule_name:row.name}},function (rdata){
			  bt.msg(rdata)
			  if(rdata.status) that.portRuleTable($('#portRules [name=search_dir]').val(),$('#portRules .search_input').val())
			},'删除当前端口规则')
		  });
		},

		/**
		 * @description 屏蔽ip列表
		 */
		ipRuleTable: function () {
		  var that = this;
		  $('#ipRule').empty()
		  return bt_tools.table({
			el: '#ipRule',
			url: '/safe/firewall/get_drop_ips',
			load: '获取IP规则列表',
			default: 'IP规则列表为空', // 数据为空时的默认提示
			height: $(window).height() - 370,
			// beforeRequest: 'model',
			dataFilter: function (res) {
				that.over_ip_shielding_list = res
				return { data: res };
			},
			tootls: [
			  { // 按钮组
				type: 'group',
				positon: ['left', 'top'],
				list: [{
				  title: '添加IP规则',
				  active: true,
				  event: function (ev,_that) {
					that.editIpRule('shielding',_that)
				  }
				},
				//  {
				//   title: '导入规则',
				//   event: function (ev,_that) {
				// 	that.import_or_export_view('ip','import',_that)
				//   }
				// },
				{
				  title: '导出规则',
				  event: function (ev,_that) {
					that.import_or_export_view('ip','export',_that)
				  }
				}]
			  },{
				type: 'search',
				positon: ['right', 'top'],
				placeholder: '请输入IP/备注',
				searchParam: 'search', //搜索请求字段，默认为 search
				value: '',// 当前内容,默认为空
			  }
			],
			column: [
			  {fid: 'ip', title: 'IP地址', width: 200},
			  {fid: 'type', title: '类型',template:function (item) {
				return '<span>' + (item['type'] == 'drop' ? '拦截' : item['type']) + '</span>'
			  }},
			  {fid: 'ps', title: '备注', width:200},
			  {
				title: '操作',
				type: 'group',
				width: 150,
				align: 'right',
				group: [{
				  title: '删除',
				  event: function (row, index, ev, key, _that) {
					that.removeIpRule(row,_that)
				  }
				}]
			  }]
		  })
		},
		/**
		 * @description 白名单ip列表
		 */
		whiteipRuleTable: function () {
			var that = this;
			$('#whiteipRule').empty()
			return bt_tools.table({
			  el: '#whiteipRule',
			  url: '/safe/firewall/get_white_ips',
			  load: '获取IP规则列表',
			  default: 'IP规则列表为空', // 数据为空时的默认提示
			  height: $(window).height() - 370,
			  // beforeRequest: 'model',
			  dataFilter: function (res) {
				that.over_ip_white_list = res
				return { data: res };
		      },
			  tootls: [
				{ // 按钮组
				  type: 'group',
				  positon: ['left', 'top'],
				  list: [{
					title: '添加IP规则',
					active: true,
					event: function (ev,_that) {
					  that.editIpRule('white',_that)
					}
				  },
				//   {
				// 	title: '导入规则',
				// 	event: function (ev,_that) {
				// 	  that.import_or_export_view('cip','import',_that)
				// 	}
				//   },
				   {
					title: '导出规则',
					event: function (ev,_that) {
					  that.import_or_export_view('cip','export',_that)
					}
				  }]
				},{
				  type: 'search',
				  positon: ['right', 'top'],
				  placeholder: '请输入IP/备注',
				  searchParam: 'search', //搜索请求字段，默认为 search
				  value: '',// 当前内容,默认为空
				}
			  ],
			  column: [
				{fid: 'ip', title: 'IP地址', width: 200},
				{fid: 'type', title: '类型',template:function (item) {
				  return '<span>' + (item['type'] == 'drop' ? '拦截' : '放行') + '</span>'
				}},
				{fid: 'ps', title: '备注', width:200},
				{
				  title: '操作',
				  type: 'group',
				  width: 150,
				  align: 'right',
				  group: [{
					title: '删除',
					event: function (row, index, ev, key, _that) {
					  that.removeWhiteIpRule(row,_that)
					}
				  }]
				}]
			})
		},
		/**
		 * @description 添加屏蔽IP IP白名单
		 * @param { object } type 类型
		 */
		editIpRule: function (type,_table){
		  layer.open({
			type: 1,
			area:"400px",
			title: type == 'white'?'添加IP白名单':'添加屏蔽IP',
			closeBtn: 2,
			shift: 5,
			shadeClose: false,
			btn: ['提交','取消'],
			content: '<div class="ptb20" id="editPortRuleForm"></div>',
			yes:function(index,layers){
				var formValue = ip_form.$get_form_value()
				if (formValue.ip == '') return layer.msg('请输入IP地址', { icon: 2 })
                if (formValue.ps == '') return layer.msg('请输入备注', { icon: 2 })
				bt_tools.send({ url: '/safe/firewall/'+ (type == 'white'?'add_white_ip':'add_drop_ip'), data:formValue},function (rdata){
					bt.msg(rdata)
					if(rdata.status) {
						layer.close(index)
						_table.$refresh_table_list(false)
					}
				}, (type == 'white'?'添加IP白名单':'添加屏蔽IP'))
			},
			success:function(layero,index){
				ip_form = bt_tools.form({
					el:'#editPortRuleForm',
					form: [
						{
							label:'IP地址',
							group:{
								type:'text',
								name:'ip',
								width:'245px',
								placeholder:'参考格式:127.0.0.1,192.168.1.0/24',
							}
						},{
							label:'备注',
							group:{
								type:'text',
								name:'ps',
								width:'245px',
								placeholder:'请输入备注',
							}
						}],
				})
				$('#editPortRuleForm [name=ip]').on('input',function () {
					$('#editPortRuleForm [name=ps]').val($(this).val())
				})
			}
		  })
		},

		/**
		 * @description 删除屏蔽IP规则
		 */
		removeIpRule:function(row,_table){
		  var that = this;
		  layer.confirm('是否删除当前屏蔽IP,是否继续？',{btn:['确认','取消'],icon:3,closeBtn: 2,title:'删除屏蔽IP'},function(index){
			layer.close(index);
			bt_tools.send({ url:'/safe/firewall/del_drop_ip', data:{ip:row.ip}},function (rdata){
			  bt.msg(rdata)
			  if(rdata.status) _table.$refresh_table_list(false)
			},'删除规则')
		  });
		},
		/**
		 * @description 删除白名单IP规则
		 */
		 removeWhiteIpRule:function(row,_table){
			var that = this;
			layer.confirm('是否删除当前白名单IP,是否继续？',{btn:['确认','取消'],icon:3,closeBtn: 2,title:'删除IP白名单'},function(index){
			  layer.close(index);
			  bt_tools.send({ url:'/safe/firewall/del_white_ip', data:{ip:row.ip}},function (rdata){
				bt.msg(rdata)
				if(rdata.status) _table.$refresh_table_list(false)
			  },'删除规则')
			});
		  },

		/**
		 * @description 端口转发列表
		 */
		portForwardTable: function () {
		  var that = this;
		  $('#portForward').empty()
		  return bt_tools.table({
			el: '#portForward',
			url: '/safe/firewall/get_portproxys',
			load: '获取端口转发列表',
			default: '端口转发列表为空', // 数据为空时的默认提示
			height: $(window).height() - 440,
			// beforeRequest: 'model',
			tootls: [
			  { // 按钮组
				type: 'group',
				positon: ['left', 'top'],
				list: [{
				  title: '添加端口转发',
				  active: true,
				  event: function (ev,_that) {
					that.editPortForward(false,_that)
				  }
				}]
			  },
			  {
				type: 'search',
				positon: ['right', 'top'],
				placeholder: '请输入IP地址/端口号',
				searchParam: 'search', //搜索请求字段，默认为 search
				value: '',// 当前内容,默认为空
			  },
			],
			column: [
			  {title: '本地IP地址',fid: 'local_ip',  width: 100},
			  {title: '本地端口号', fid: 'local_port'},
			  {title: '远程IP地址', fid: 'remote_ip'},
			  {title: '远程端口号', fid: 'remote_port'},
			  {
				title: '操作',
				type: 'group',
				width: 150,
				align: 'right',
				group: [{
				  title: '编辑',
				  event: function (row, index, ev, key, _that) {
					that.editPortForward(row,_that)
				  }
				}, {
				  title: '删除',
				  event: function (row, index, ev, key, _that) {
					that.removePortForward(row,_that)
				  }
				}]
			}],
			success: function (layero,indexs) {
				if(!$('#portForward .help-info-text').length){
					$('#portForward').append('<ul class="help-info-text c7">\
						<li>【0.0.0.0】表示本地IPV4地址，【::】表示本地IPV6地址</li>\
						<li>将本地【IPV4/IPV6】某个端口的流量转发到远程服务器的指定端口</li>\
						<li>本地端口必须是【未使用】状态，远程服务器端口必须是【已使用】状态</li>\
					</ul>')
				}
			}
		  })
		},

		/**
		 * @description 添加/修改端口转发
		 * @param row
		 */
		editPortForward: function (row,_table) {
		  var isEdit = !!row, that = this,forward_form = null
		  row = row || []
		  layer.open({
			type: 1,
			area:"400px",
			title: (!isEdit?'添加':'编辑') + '端口转发规则',
			closeBtn: 2,
			shift: 5,
			shadeClose: false,
			btn: ['提交','取消'],
			content: '<div class="ptb20" id="editPortRuleForm"></div>',
			yes:function(index,layers){
				var formValue = forward_form.$get_form_value()
				if (formValue.local_port == '') return layer.msg('请输入本地端口', { icon: 2 })
				if (formValue.remote_ip == '') return layer.msg('请输入远程IP地址', { icon: 2 })
				if (formValue.remote_port == '') return layer.msg('请输入远程端口', { icon: 2 })
				if (isEdit) formValue['local_ip'] = formValue.local_ip;
                if (!isEdit) formValue['s_type'] = formValue.ip_type;
				bt_tools.send({ url: '/safe/firewall/'+ (isEdit ? 'set_portproxy' : 'add_portproxy'), data:formValue},function (rdata){
					bt.msg(rdata)
					if(rdata.status) {
						layer.close(index)
						_table.$refresh_table_list(false)
					}
				}, (!isEdit?'添加':'编辑')+'端口转发')
			},
			success:function(layero,index){
				forward_form = bt_tools.form({
					el:'#editPortRuleForm',
					form: [
						{
							label:'IP类型',
							group:{
								type:'select',
								name:'ip_type',
								width:'245px',
								list:[
									{title:'所有',value:'all'},
									{title:'IPV4',value:'v4'},
									{title:'IPV6',value:'v6'}
								]
							},
							hide: isEdit ? true : false,
						},{
							label:'本地IP',
							group:{
								type:'text',
								disabled: isEdit ? true : false,
								name:'local_ip',
								width:'245px',
								placeholder:'请输入本地IP',
							},
							hide: isEdit ? false : true,
						},{
							label:'本地端口',
							group:{
								type:'text',
								disabled: isEdit ? true : false,
								name:'local_port',
								width:'245px',
								placeholder:'请输入本地端口',
							}
						},{
							label:'远程IP',
							group:{
								type:'text',
								name:'remote_ip',
								width:'245px',
								placeholder:'请输入远程IP地址',
							}
						},{
							label:'远程端口',
							group:{
								type:'text',
								name:'remote_port',
								width:'245px',
								placeholder:'请输入远程端口',
							}
						}],
					data:row ? row : []
				})
			}
		  })

		},

		/**
		 * @description 删除端口转发
		 * @param {object} row 当前行数据
		 */
		removePortForward: function (row,_table) {
		  var that = this;
		  layer.confirm('是否删除当前端口转发,是否继续？',{btn:['确认','取消'],icon:3,closeBtn: 2,title:'删除端口转发'},function(index){
			layer.close(index);
			bt_tools.send({
			  url:'/safe/firewall/del_portproxy',
			  data:{local_ip: row.local_ip, local_port: row.local_port, remote_ip: row.remote_ip}
			}, function (rdata) {
			  bt.msg(rdata)
			  if(rdata.status) _table.$refresh_table_list(false)
			},'删除端口转发')
		  });
		},
		// 导入或导出视图
		import_or_export_view: function (title, type,_table) {
			var that = this, show_data = '';
			if (type == 'export') {
				if (title == 'rule') show_data = JSON.stringify(this.over_port_list)
				if (title == 'ip') {
					this.each(this.over_ip_shielding_list, function (index, item) {
						show_data += item['ip'] + "&#10;"
					})
				}
				if (title == 'cip') {
					this.each(this.over_ip_white_list, function (index, item) {
						show_data += item['ip'] + "&#10;"
					})
				}
			}
			layer.open({
				type: 1,
				title: (type == 'import' ? '导入' : '导出') + (title == 'rule' ? '端口规则' : (title == 'ip'?'屏蔽IP':'IP白名单')) + "列表",
				area: ['550px', '400px'],
				closeBtn: 2,
				shadeClose: false,
				content: '<div class="pd20">\
					<div class="view-box">\
						<textarea rows="15" style="padding:5px 10px;width:100%;height:100%;border-radius:2px;border:1px solid #ccc;" name="config">'+ show_data + '</textarea>\
						<div class="placeholder c9" style="padding-left: 16px; display:none">每行填写一个ip，例：</br>192.168.1.1</br>192.168.2.2</div>\
					</div>\
					<div class="bt-form-submit-btn">\
						<button type="button" class="btn btn-default btn-sm im-ex-colse">取消</button>\
						<button type="button" class="btn btn-success btn-sm btn-submit-config" style="margin-right:10px;display:'+ (type == 'export' ? 'none' : 'inline-block;') + ';">导入</button>\
					</div>\
				</div>',
				success: function (index, layero) {
					// 屏蔽ip 超文本提示语显示隐藏
					if (title == 'ip' || title == 'cip') {
						if (show_data == '') { $('.view-box .placeholder').show() }
						$('[name=config]').focus(function () {
							$('.view-box .placeholder').hide()
						})
						$('[name=config]').blur(function () {
							var _configs = $('[name=config]').val();
							_configs == '' ? $('.view-box .placeholder').show() : $('.view-box .placeholder').hide()
						});
					}
					$('.btn-submit-config').click(function () {
						var _config = $('[name=config]').val();
						if (type == 'import') {
							if (_config == '') {
								layer.msg('导入数据不能为空', { icon: 2 });
								return false;
							}
							bt_tools.send({url:'/safe/firewall/' + (title == 'rule' ? 'import_rules' :(title == 'ip'?'import_drop_ip':'import_white_ip')) , data:{data:_config}}, function (res) {
								if (res.status) {
									_table.$refresh_table_list(false)
									layer.close(layero)
								}
								setTimeout(function () {
									layer.msg(res.msg, { icon: res.status ? 1 : 2 })
								}, 1000)
							})
						}
					})
					$('.im-ex-colse').click(function () {
						layer.close(layero)
					})
				}
			})
		},
		/**
		 * @description 规则导入
		 * @param
		 */
		ruleImport: function (name){
		  var _this = this;
		  layer.open({
			type: 1,
			area:"400px",
			title: '导入规则',
			closeBtn: 2,
			shift: 5,
			shadeClose: false,
			btn:['导入','取消'],
			content:'<div class="bt-form bt-form" style="padding:15px 0px">\
									<div class="line" style="text-align: center;">\
							  <div class="info-r c4" style="margin-left:70px;">\
								  <div class="detect_input">\
									  <input type="text" class="input_file" placeholder="请选择文件" style="width:170px;">\
									  <input type="file" class="file_input" name="点我上传" id="fileInput" style="display:none;"/>\
									  <button type="button" class="select_file" onclick="$(\'#fileInput\').click()">选择文件</button>\
								  </div>\
							  </div>\
						  </div>\
								</div>',
			yes:function(index,layers){
			  if (!$("#fileInput")[0].files[0]){
				layer.msg('请选择要导入的文件!',{icon:2});
				return false;
			  }
			  _this.upload({name:name, _fd:$("#fileInput")[0].files[0]}, 0, index);
			},
			success:function(){
			  $("#fileInput").on('change',function(){
				if(!$("#fileInput")[0].files[0]){
				  $(".input_file").val("");
				}
				var filename = $("#fileInput")[0].files[0].name;
				$(".input_file").val(filename)
			  });
			},
		  });
		},

		/**
		 * @description 规则导出
		 */
		ruleExport: function (type){
		  bt_tools.send({
			url: '/safe/firewall/export_rules',
			data:{data:JSON.stringify({rule_name:type})},
		  },function (rdata){
			if(rdata.status){
			  window.open('/download?filename='+rdata.msg);
			}else{
			  bt_tools.msg(rdata);
			}
		  },'导出规则')
		},
	},
	// SSH管理
	ssh:{
		/**
		 * @description SSH管理列表
		 */
		event:function (){
		  var that = this;
		  // 切换系统防火墙菜单事件
		  $('#sshView').unbind('click').on('click', '.tab-nav-border span', function () {
			var index = $(this).index();
			$(this).addClass('on').siblings().removeClass('on');
			$(this).parent().next().find('.tab-block').eq(index).addClass('on').siblings().removeClass('on');
			$('.state-content').show().find('.ssh-header').show().siblings().hide();
			that.cutSshTab(index);
		  })

		  $('#sshView .tab-nav-border span').eq(0).trigger('click');

		  // SSH开关
		  $('#isSsh').unbind('click').on('click',function(){
			var _that = $(this), status = _that.prop("checked")?0:1;
			bt.firewall.set_mstsc_status(status,function(rdata){
			  if(rdata === -1){
				_that.prop("checked",!!status);
			  }else{
				bt.msg(rdata);
				that.getSshInfo();
			  }
			});
		  })

		  // 保存SSH端口
		  $('.save_ssh_port').unbind('click').on('click',function (){
			var port = $(this).prev().val();
			if(port === '') return bt.msg({msg:'端口不能为空！',icon:2});
			if(!bt.check_port(port)) return bt.msg({msg:'端口格式错误，可用范围：1-65535，<br />请避免使用以下端口<br />【80,443,8080,8443,8888】',icon:2});
			bt.firewall.set_mstsc(port,function (rdata) {
				bt_tools.msg(rdata)
			});
		  })

		  // root登录
		  $('[name="root_login"]').unbind('click').on('click',function(){
			var _that = $(this), status = _that.prop("checked");
			bt_tools.send({
			  url:'/ssh_security?action=' + (status?'set_root':'stop_root')
			},function (rdata){
			  bt_tools.msg(rdata)
			},'设置SSH设置')
		  })

		  // SSH密码登录
		  $('[name="ssh_paw"]').unbind('click').on('click',function (){
			var _that = $(this), start = _that.prop("checked");
			bt_tools.send({
			  url:'/ssh_security?action=' + (start?'set_password':'stop_password')
			},function (rdata){
			  bt_tools.msg(rdata)
			},'设置SSH密码登录状态')
		  })

		  // SSH密钥登录
		  $('[name="ssh_pubkey"]').unbind('click').on('click',function(){
			var _that = $(this);
			var start = _that.prop("checked");
			if(start){
			  that.setTemplateSshkey();
			}else{
			  bt_tools.send({
				url:'/ssh_security?action=stop_key'
			  },function (rdata){
				that.getSeniorSshInfo();
				bt_tools.msg(rdata);
			  },'关闭SSH密钥登录')
			}
		  })

		  // 登录告警
		  $('[name="ssh_login_give"]').unbind('click').on('click',function(){
			var _that = $(this), status = _that.prop("checked");
			bt_tools.send({
			  url:'/ssh_security?action=' + (status?'start_jian':'stop_jian')
			},function (rdata){
			  bt_tools.msg(rdata)
			},'设置SSH登录告警')
		  })

		  // 查看密钥
		  $('.checkKey').unbind('click').on('click',function (){
			that.setSshKeyView()
		  })

		  // 设置登录告警
		  $('.setSshLoginAlarm').unbind('click').on('click',function (){
			that.setSshLoginAlarmView();
		  });

		  // 下载密钥
		  $('.downloadKey').unbind('click').on('click',function (){
			window.open('/download?filename=/root/.ssh/id_rsa')
		  })

		  // 登录详情
		  $('#sshDetailed').unbind('click').on('click','a',function (){
			var index = $(this).data('index');
			$('#sshView .tab-nav-border>span').eq(1).addClass('on').siblings().removeClass('on');
			$('#sshView .tab-block').eq(1).addClass('on').siblings().removeClass('on');
			$('#loginLogsContent>div:eq('+ index +')').show().siblings().hide();
			that.loginLogsTable({p:1,type: index});
		  })

		  // 防爆破
		  $('#fail2ban').unbind('click').on('click','a',function(){
			var type = $(this).data('type');
			switch (type){
			  case 'install':
				bt.soft.install('fail2ban')
				break;
			  case 'open':
				bt.soft.set_lib_config('fail2ban','Fail2ban防爆破')
				break;
			}
		  })

		  // 切换登录日志类型
		  $('#loginLogsContent').unbind('click').on('click','.cutLoginLogsType button',function(){
			var type = $(this).data('type');
			$(this).addClass('btn-success').removeClass('btn-default').siblings().addClass('btn-default').removeClass('btn-success');
			$('#loginLogsContent>div:eq('+ type +')').show().siblings().hide();
			that.loginLogsTable({p:1,type: Number(type),filter: $(this).parent().prev().find('[name=filter]').prop("checked")});
		  })

		  // 刷新登录日志
		  $('#refreshLoginLogs').unbind('click').on('click',function(){
			var type = $('#cutLoginLogsType button.btn-success').data('type');
			that.loginLogsTable({type:type });
		  });
		},

		/**
		 * @description 切换SSH菜单
		 * @param {number} index 索引
		 */
		cutSshTab:function (index){
		  switch (index){
			case 0:
			  this.getSshInfo();
			//   this.getLoginAlarmInfo();
			//   this.getSeniorSshInfo();
			//   this.getSshLoginAlarmInfo();
			  break;
			case 1:
				var type = $('.cutLoginLogsType button.btn-success').data('type')
			  this.loginLogsTable({p:1, type: type? type : 0,filter: $('.cutLoginLogsType button.btn-success').parent().prev().find('[name=filter]').prop("checked")});
			  break;
		  }
		},
		/**
		 * @description 获取登录告警信息
		 */
		getLoginAlarmInfo:function(){
		  bt_tools.send({
			url:'/ssh_security?action=get_jian'
		  },function (rdata){
			$('#ssh_login_give').prop('checked',rdata.status);
		  }, {load:'获取登录告警状态',verify:false})
		},

		/**
		 * @description 设置密钥登录
		 */
		setTemplateSshkey:function(){
		  var _this = this;
		  layer.open({
			title:'开启SSH密钥登录',
			area:'250px',
			type:1,
			closeBtn: 2,
			btn:['提交','关闭'],
			content:'<div class="bt-form bt-form pd20">'+
				'<div class="line "><span class="tname">SSH密码登录</span><div class="info-r "><select class="bt-input-text mr5 ssh_select_login" style="width:70px"><option value="yes">开启</option><option value="no">关闭</option></select></div></div>'+
				'<div class="line "><span class="tname">密钥加密方式</span><div class="info-r "><select class="bt-input-text mr5 ssh_select_encryption" style="width:70px"><option value="rsa">rsa</option><option value="dsa">dsa</option></select></div></div>'+
				'</div>',
			yes:function(indexs){
			  var ssh_select_login = $('.ssh_select_login').val();
			  var ssh_select_encryption = $('.ssh_select_encryption').val();
			  bt_tools.send({
				url:'/ssh_security?action=set_sshkey',
				data:{ ssh:ssh_select_login, type:ssh_select_encryption }
			  },function (rdata){
				bt_tools.msg(rdata)
				layer.close(indexs)
				_this.getSeniorSshInfo()
			  },'开启SSH密钥登录')
			},
			cancel:function(index){
			  $('[name="ssh_pubkey"]').prop('checked',false);
			},
			btn2:function(index){
			  $('[name="ssh_pubkey"]').prop('checked',false);
			}
		  })
		},

		/**
		 * @description 设置SSH登录告警
		 */
		setSshLoginAlarmView:function(){
		  var that = this;
		  layer.open({
			title:'SSH登录告警',
			area: '1010px',
			type: 1,
			closeBtn: 2,
			content: '\
					<div class="bt-w-main">\
						<div class="bt-w-menu">\
							<p class="bgw">登录日志</p>\
							<p>IP白名单</p>\
						</div>\
						<div class="bt-w-con pd15">\
							<div class="plugin_body">\
								<div class="content_box news-channel active">\
									<div class="bt-form-new inline"></div>\
									<div id="login_logs_table" class="divtable mt10">\
										<div style="width: 100%; border: 1px solid #ddd; overflow: auto;">\
											<table class="table table-hover" style="border: none;">\
												<thead>\
													<tr>\
														<th>详情</th>\
														<th class="text-right">添加时间</th>\
													</tr>\
												</thead>\
												<tbody>\
													<tr>\
														<td colspan="2" class="text-center">暂无数据</td>\
													</tr>\
												</tbody>\
											</table>\
										</div>\
										<div class="page"></div>\
									</div>\
									<ul class="help-info-text c7">\
										<li></li>\
									</ul>\
								</div>\
								<div class="content_box hide">\
									<div class="bt-form">\
										<div class="box" style="display:inline-block;">\
											<input name="ipAddress" class="bt-input-text mr5" type="text" style="width: 220px;" placeholder="请输入IP" />\
											<button class="btn btn-success btn-sm addAddressIp">添加</button>\
										</div>\
									</div>\
									<div id="whiteIpTable"></div>\
									<ul class="help-info-text c7">\
										<li style="list-style:inside disc">只允许设置ipv4白名单</li>\
									</ul>\
								</div>\
							</div>\
						</div>\
					</div>',
			success: function ($layer, indexs) {
						// layer
			  var _that = this;

						// 切换菜单
						$layer.find('.bt-w-menu p').click(function () {
							var index = $(this).index();
							$(this).addClass('bgw').siblings('.bgw').removeClass('bgw');
							$layer.find('.content_box').addClass('hide');
							$layer.find('.content_box').eq(index).removeClass('hide');
							switch (index) {
								// 登录日志
								case 0:
									_that.renderAlarm();
									_that.renderLogsTable(1, false);
									break;
								// IP白名单
								case 1:
									_that.renderWhiteIpTable()
									break;
							}
						});

						// 设置告警通知
						$('.news-channel .bt-form-new').on('change', 'input[type="checkbox"]', function () {
							var $this = $(this);
							var name = $this.attr('name');
							var checked = $this.is(':checked');
							var action = checked ? 'set_login_send' : 'clear_login_send'
							bt_tools.send({
				  url: '/ssh_security?action=' + action,
				  data:{ type: name }
				}, function (rdata) {
				  bt_tools.msg(rdata);
								if (rdata.status) {
									if (checked) {
										$('.news-channel .bt-form-new input[type="checkbox"]').prop('checked', false);
										$this.prop('checked', true);
									}
									that.getSshLoginAlarmInfo();
								}
				}, '配置告警通知');
						});

						// 登录日志分页操作
						$('#login_logs_table .page').on('click', 'a', function (e) {
							e.stopPropagation();
							e.preventDefault();
							var page = $(this)
								.attr('href')
								.match(/p=([0-9]*)/)[1];
							_that.renderLogsTable(page);
						});

						// 添加ip
						$('.addAddressIp').click(function () {
							var address = $('[name="ipAddress"]');
							var ip = address.val();
				address.val('');
				if (!ip) {
								bt_tools.msg({ msg:'请输入IP地址', status: false });
								return;
							}
				bt_tools.send({
				  url:'/ssh_security?action=add_return_ip',
				  data:{ ip: ip }
				}, function (rdata) {
				  bt_tools.msg(rdata);
				  _that.renderWhiteIpTable();
				},'添加白名单')
						});

						$layer.find('.bt-w-menu p').eq(0).click();
			},
					// 生成告警
					renderAlarm: function () {
						var load = bt_tools.load('获取SSH登录告警配置，请稍候...');
						// 获取告警列表
						bt_tools.send({
							url: '/ssh_security?action=get_msg_push_list',
						}, function (alarms) {
							// 获取选中告警
							bt_tools.send({
								url: '/ssh_security?action=get_login_send',
							}, function (send) {
								load.close();
								var html = '';
								var tits = [];
								// 当前选中的告警key
								var cKey = send.msg;
								// 渲染生成告警列表
								$.each(alarms, function (key, item) {
									if (item.name === 'sms') return;
									var checked = cKey === item.name ? 'checked="checked"' : '';
									html += '\
									<div class="form-item">\
										<div class="form-label">通知' + item.title + '</div>\
										<div class="form-content">\
											<input type="checkbox" id="' + item.name + '_alarm" class="btswitch btswitch-ios" ' + checked + ' name="' + item.name + '" />\
											<label class="btswitch-btn" for="' + item.name + '_alarm"></label>\
										</div>\
									</div>';
									tits.push(item.title);
								});
								$('.news-channel .bt-form-new').html(html);
								$('.news-channel .help-info-text li').eq(0).text(tits.join('/') + '只能同时开启一个');
							});
						});
					},
					// 生成日志表格
					renderLogsTable: function (p, load) {
						p = p || 1;
						load = load !== undefined ? load : true;
						if (load) var loadT = bt_tools.load('正在获取登录日志，请稍候...');
						bt_tools.send({
							url: '/ssh_security?action=get_logs',
							data: { p: p, p_size: 8, }
						}, function (rdata) {
							if (load) loadT.close();
							var html = '';
							if (rdata.data) {
								for (var i = 0; i < rdata.data.length; i++) {
									var item = rdata.data[i];
									html += '<tr><td style="white-space: nowrap;" title="' + item.log + '">' + item.log + '</td><td class="text-right">' + item.addtime + '</td></tr>';
								}
							}
							html = html || '<tr><td class="text-center">暂无数据</td></tr>';
							$('#login_logs_table table tbody').html(html);
							$('#login_logs_table .page').html(rdata.page || '');
						});
					},
					// 生成IP白名单表格
					renderWhiteIpTable: function () {
						var _that = this;
						if (this.ipTable) {
							this.ipTable.$refresh_table_list();
							return;
						}
						this.ipTable = bt_tools.table({
							el: '#whiteIpTable',
							url: '/ssh_security?action=return_ip',
							load: '获取SSH登录白名单',
							autoHeight: true,
							height: '425px',
							default: "SSH登录白名单为空",
							dataFilter: function (data) {
								return { data: data.msg };
							},
							column: [
								{
									title: 'IP地址',
									template: function (item) {
										return '<span>'+ item + '</span>';
									}
								},
								{
									title: '操作',
									type: 'group',
									width: 150,
									align: 'right',
									group: [
										{
											title: '删除',
											event: function (row, index) {
												bt_tools.send({
													url: '/ssh_security?action=del_return_ip',
													data: { ip: row }
												},function (rdata){
													bt_tools.msg(rdata)
													_that.renderWhiteIpTable();
												}, '删除IP白名单');
											}
										}
									]
								}
							]
						})
					}
		  })
		},

		/**
		 * @description 设置SSH密钥视图
		 */
		setSshKeyView:function(){
		  bt_tools.send({
			url:'/ssh_security?action=get_key'
		  },function (rdata){
			layer.open({
			  title:'SSH登录密钥',
			  area:'400px',
			  type:1,
			  closeBtn: 2,
			  content:'<div class="bt-form pd20">\
				<textarea id="ssh_text_key" class="bt-input-text mb10" style="height:220px;width:360px;line-height: 22px;">'+ rdata.msg +'</textarea>\
				<div class="btn-sshkey-group">\
				  <button type="button" class="btn btn-success btn-sm mr5 btn-copy-sshkey">复制</button>\
				  <button type="button" class="btn btn-success btn-sm btn-download-sshkey">下载</button>\
				</div>\
			  </div>',
			  success:function (layers,indexs){
				$('.btn-copy-sshkey').on('click',function(){
				  bt.pub.copy_pass($('#ssh_text_key').val());
				})
				$('.btn-download-sshkey').on('click',function(){
				  window.open('/download?filename=/root/.ssh/id_rsa')
				})
			  }
			})
		  },'获取SSH登录密钥')
		},

		/**
		 * @description 获取SSH信息
		 */
		getSshInfo:function (){
		  bt_tools.send({
			url: '/safe/ssh/GetSshInfo',
			verify: false
		  },function (rdata){
			var error = rdata.error;
			$('#fail2ban').html(rdata.fail2ban?'<a href="javascript:;" class="btlink" data-type="open">已安装，查看详情</a>':'<a href="javascript:;" style="color: red;" data-type="install">未安装，点击安装</a>');
			$('#sshDetailed').html('<a href="javascript:;" class="btlink" data-index="1">成功：'+ error.success +'</a><span style="margin: 0 8px">/</span><a href="javascript:;" style="color: red;" data-index="2">失败：'+ error.error +'</a>');
			$('#isSsh').prop("checked",rdata.status);
			$('[name="ssh_port"]').val(rdata.port);
		  },'SSH配置信息');
		},
		/**
		 * @description 获取高级SSH信息
		 */
		getSeniorSshInfo:function (){
		  bt_tools.send({
			url: '/ssh_security?action=get_config',
			verify: false
		  },function (rdata){
			$('[name="ssh_paw"]').prop("checked",rdata.password === 'yes');
			$('[name="ssh_pubkey"]').prop("checked",rdata.pubkey === 'yes')
			$('[name="root_login"]').prop("checked",rdata.root_is_login === 'yes')
		  },'SSH高级配置信息');
		},
			/**
		 * @description 获取SSH登录告警
		 */
		getSshLoginAlarmInfo: function () {
				var that = this;
				bt_tools.send({
			url: '/ssh_security?action=get_login_send',
			verify: false
		  }, function (send) {
					var data = that.msgPushData;
					if (!data || $.isEmptyObject(data)) {
						bt_tools.send({
							url: '/ssh_security?action=get_msg_push_list',
							verify: false
						}, function (msgData) {
							that.msgPushData = msgData
							that.renderLoginAlarmInfo(send);
						});
					} else {
						that.renderLoginAlarmInfo(send);
					}

		  },'SSH登录告警配置');
		},
			/**
		 * @description 渲染SSH登录告警配置
		 */
		renderLoginAlarmInfo: function (send) {
			var data = this.msgPushData || {};
			var map = {}
			$.each(data, function (key, item) {
				if (key === 'sms') return
				map[key] = item.title
			});
			var key = send.msg;
			var title = map[key];
			if (send.status && title) {
				$('a.setSshLoginAlarm').removeClass('bt_warning').addClass('btlink');
				$('a.setSshLoginAlarm').text(title + '已配置');
			} else {
				$('a.setSshLoginAlarm').addClass('bt_warning').removeClass('btlink');
				$('a.setSshLoginAlarm').text('告警通知未配置');
			}
		},

		/**
		 * @description 登录日志
		 */
		loginLogsTable:function(param){
		  if(!param) param = { p:1, type:0 };
		  var logs = [['All','日志','get_ssh_list'],['Success','成功日志','get_ssh_success'],['Error','失败日志','get_ssh_error']];
		  var filter = param['filter'] === undefined ? false : param['filter']
		  var type = logs[param.type][0] , tips = logs[param.type][1];
		  var that = this;
		  $('#login'+ type +'Logs').empty();
		  var arry = ['全部','登录成功','登录失败'];
		  var html = $('<div class="btn-group mr10 cutLoginLogsType"></div>');
		  $.each(arry,function (i,v){
			html.append('<button type="button" class="btn btn-sm btn-'+ (i === param.type ?'success':'default') +'" data-type="'+ i +'">'+ v +'</button>')
		  })
		  return bt_tools.table({
			el: '#login'+ type +'Logs',
			url: '/safe/syslog/' + logs[param.type][2],
			load: '获取SSH登录' + tips,
			default: 'SSH登录'+ tips +'为空', // 数据为空时的默认提示
			autoHeight: true,
			dataVerify:false,
			tootls: [
			  { // 按钮组
				type: 'group',
				positon: ['left', 'top'],
				list: [{
				  title: '刷新列表',
				  active: true,
				  event: function (ev,that) {
					that.$refresh_table_list(true)
				  }
				}]
			  },
			  { // 搜索内容
				type: 'search',
				positon: ['right', 'top'],
				placeholder: '请输入登录IP/用户名',
				searchParam: 'search', //搜索请求字段，默认为 search
			  },{ //分页显示
				type: 'page',
				number: 20
			  }
			],
			dataFilter: function (data) {
			  if(typeof data.status === "boolean" && !data.status){
					$('#loginLogsContent').hide().next().show();
					return { data: [] }
			  }
			  return {data:data}
			},
			beforeRequest: function (data) {
				data['filter_invalid'] = filter ? 1 : 0
			  if(typeof data.data === "string"){
				delete data.data
				return {data: JSON.stringify(data)}
			  }
			  return {data: JSON.stringify(data)}
			},
			column: [
			  {title: 'IP地址:端口',fid: 'address',width:'150px', template:function (row){
				  return '<span>'+ (row.address ? row.address : '--') + ':' + (row.port !== '0' && row.port !== '-' ? row.port : '--' ) + '</span>';
				}},
			  // {title: '登录端口',fid: 'port'},
			  {title: '归属地',template:function (row){
				  return '<span>'+ (row.area?'' + row.area.info + '':'-') +'</span>';
				}},
			  {title: '用户',fid: 'user'},
			  {title: '状态', template: function (item) {
				  var status = Boolean(item.status);
				  return '<span style="color:'+ (status?'#20a53a;':'red') +'">'+ (status ? '登录成功' : '登录失败') +'</span>';
				}},
			  {title: '操作时间', fid: 'time', width:150}
			],
			success:function (config){
				$(config.config.el + ' .tootls_top .pull-right .btn-group').remove()
				$('.bt_search').prev().remove()
				var num = config.config.el.indexOf('All') > -1 ? 0 : config.config.el.indexOf('Success') > -1 ? 1 : 2
				$(config.config.el + ' .tootls_top .pull-right').prepend('<div class="btn-group mr10" style="position: relative;vertical-align: middle;">\
					<label class="mr20 cursor-pointer" for="filteruser_'+ num +'" style="font-weight:normal;display: inline-flex;width: 90px;justify-content: space-between;vertical-align: middle;">\
						<input type="checkbox" class="filteruser cursor-pointer" style="margin:0;" id="filteruser_'+ num +'" name="filter">过滤无效用户\
					</label>\
				</div>')
				$('.bt_search').before(html)
				$(config.config.el+' [name=filter]').prop("checked",filter)
				$(config.config.el+' [name=filter]').change(function () {
					that.loginLogsTable({p:1,type: num,filter: $(config.config.el+' [name=filter]').prop('checked')});
				})
			  $('#login'+ type +'Page').html(firewall.renderLogsPages(20,param.p,config.data.length))
			}
		  })
		},

		/**
		 * @description ssh白名单
		 */
		sshWhiteList:function(){
		  var that = this;
		  return bt_tools.table({
			el: '#loginWhiteList',
			url: '/ssh_security?action=return_ip',
			load: '获取SSH登录白名单',
			default: 'SSH登录白名单为空', // 数据为空时的默认提示
			autoHeight: true,
			height: '250px',
			dataFilter: function (data) {
			  return { data:data.msg };
			},
			column: [
			  {title: 'IP地址',template: function (item) {
				  return '<span>'+ item + '</span>';
				}},
			  {
				title: '操作',
				type: 'group',
				width: 150,
				align: 'right',
				group: [{
				  title: '删除',
				  event: function (row, index) {
					console.log(row, index)
					bt_tools.send({
					  url: '/ssh_security?action=del_return_ip',
					  data:{ip:row}
					},function (rdata){
					  bt_tools.msg(rdata)
					  that.sshWhiteList()
					},'删除IP白名单');
				  }
				}]
			  }
			]
		  })
		},
	},
	// 日志审计
	logAudit:{
		plugin_name: 'win_event',
		selectIndex: 0,
		p:1,
		timeRange: {
            start: 0,
            end: 0,
            value: ''
        },
		/**
		 * @description 事件绑定
		 */
		event:function (){
			var that = this;
			$('.state-content').hide()
			var ltd = parseInt(bt.get_cookie('ltd_end')  || -1)
      if(ltd < 0){
				return $('#logAudit .daily-thumbnail').show().prevAll().hide()
			}
			$('#logAudit').height($(window).height() - 180).css({'overflow': 'hidden'})
			$('#logAudit .tab-con').css({'overflow': 'visible'})
			// 切换日志审计菜单事件
			$('#logAudit').unbind('click').on('click', '.tab-nav-border span', function () {
			  var index = $(this).index();
			  $(this).addClass('on').siblings().removeClass('on');
			  $(this).parent().next().find('.tab-block').eq(index).addClass('on').siblings().removeClass('on');
			  var html = '';
				switch (index) {
					case 0:
						html = '<div id="bt_app_table"></div>';
						break;
					case 1:
						html = '<div id="bt_safe_table"></div>';
						break;
					case 2:
						html = '<div id="bt_system_table"></div>';
						break;
					case 3:
						html = '<div id="bt_setup_table"></div>';
						break;
					case 4:
						html = '<div id="bt_fe_table"></div>';
						break;
				}
				$(this).parent().next().find('.tab-block').eq(index).empty().append(html);
                that.render_tools();
                that.render_table();
			})
			$('#logAudit .tab-nav-border span:eq(0)').click();
		},
		/**
         * @description 生成工具栏
         * @return void
         */
		 render_tools: function () {
            this.render_tools_top();
            this.render_tools_bottom();
        },
        /**
         * @description 生成工具栏顶部及事件
         * @return void
         */
        render_tools_top: function () {
            var html = '\
                <div class="tootls_group tools_top">\
                    <div class="tools_left"></div>\
                </div>\
            ';
            var index = this.get_menu_index();
            $('#logAudit .tab-block').eq(index).prepend(html);
            this.render_tools_top_level();
            // this.render_tools_top_time();
            this.render_tools_top_event();
        },
		/**
         * @description 生成工具栏底部及事件
         * @return void
         */
		 render_tools_bottom: function () {
			var that = this
            var html = '\
                <div class="tootls_group tools_bottom">\
                    <div class="page">\
                        <select class="page_select_number">\
                            <option value="20" selected>20条/页</option>\
                            <option value="50">50条/页</option>\
                            <option value="100">100条/页</option>\
                            <option value="500">500条/页</option>\
                            <option value="1000">1000条/页</option>\
                        </select>\
                    </div>\
                </div>\
            ';
            var index = this.get_menu_index();
            $('#logAudit .tab-block').eq(index).append(html);
            $('.tools_bottom .page_select_number').change(function () {
                that.render_table();
            });
        },
        /**
         * @description 生成查询等级复选框及事件
         * @return void
         */
        render_tools_top_level: function () {
			var that = this
            var index = this.get_menu_index();
            if (index == 1) return;
            var html = '\
                <div class="tools_item">\
                    <span class="tools_label">级别：</span>\
                    <div class="checkbox_group">\
                        <div class="checkbox_item checkbox_default">\
                            <input type="checkbox" class="checkbox-text" value="2" />\
                            <span>错误</span>\
                        </div>\
                        <div class="checkbox_item checkbox_default">\
                            <input type="checkbox" class="checkbox-text" value="3" />\
                            <span>警告</span>\
                        </div>\
                        <div class="checkbox_item checkbox_default">\
                            <input type="checkbox" class="checkbox-text" value="1" />\
                            <span>关键</span>\
                        </div>\
                        <div class="checkbox_item checkbox_default">\
                            <input type="checkbox" class="checkbox-text" value="4" />\
                            <span>信息</span>\
                        </div>\
                    </div>\
                </div>\
            ';
            $('.tools_top .tools_left').append(html);
            $('.checkbox_item span').click(function () {
                $(this).prev().click();
            });
            $('.checkbox_default input').click(function () {
                that.render_table();
            });
        },
        /**
         * @description 生成查询时间选择器及事件
         * @return void
         */
        render_tools_top_time: function () {
            var _this = this;
            var html = '\
                <div class="tools_item">\
                    <div class="bt_select_updown site_class_type">\
                        <div class="bt_select_value">\
                            <span class="bt_select_content">操作时间：近两天</span>\
                            <span class="glyphicon glyphicon-triangle-bottom ml5"></span>\
                        </div>\
                        <ul class="bt_select_list">\
                            <li class="item" data-type="1">近2小时</li>\
                            <li class="item" data-type="2">近12小时</li>\
                            <li class="item" data-type="3">近24小时</li>\
                            <li class="item active" data-type="0">近两天</li>\
                            <li class="item" data-type="4">近7天</li>\
                            <li class="item" data-type="5">近30天</li>\
                            <li class="divider" role="separator"></li>\
                            <li class="item custom">自定义范围</li>\
                        </ul>\
                    </div>\
                </div>\
            ';
            $('.tools_top .tools_left').append(html);
            $('.bt_select_value').click(function (e) {
                var $this = $(this);
                $this.next().show();
                $(document).one('click', function () {
                    $this.next().hide();
                });
                e.stopPropagation();
            });
            $('.bt_select_list').on('click', '.item', function () {
                var $this = $(this);
                var text = $this.text();
                _this.selectIndex = $this.siblings('.active').index();
                $this.addClass('active').siblings('.active').removeClass('active');
                $this.parent().prev().find('.bt_select_content').text('操作时间：' + text);
                if ($this.hasClass('custom')) {
                    layer.open({
                        type: 1,
                        area: "380px",
                        title: '自定义范围',
                        closeBtn: 2,
                        shift: 5,
                        shadeClose: false,
                        btn: ['提交', '取消'],
                        content: '\
                            <div class="bt-form pd20">\
                                <div class="line">\
                                    <span class="tname" style="width: auto;">时间范围</span>\
                                    <div class="info-r" style="margin-left: 68px;">\
                                        <input type="text" class="bt-input-text mr5" id="time_range" style="width: 100%;" placeholder="开始时间 至 结束时间">\
                                    </div>\
                                </div>\
                            </div>\
                        ',
                        success: function () {
                            var today = new Date();
                            var todayStr = bt.format_data(today.getTime() / 1000, 'yyyy-MM-dd hh:mm:ss');
                            var value = '' + todayStr + ' 至 ' + todayStr + '';
                            _this.timeRange.value = value;
                            _this.timeRange.start = Math.floor(today.getTime() / 1000);
                            _this.timeRange.end = Math.floor(today.getTime() / 1000);
                            laydate.render({
                                elem: '#time_range',
                                type: 'datetime',
                                range: '至',
                                format: 'yyyy-MM-dd HH:mm:ss',
                                value: value,
                                done: function (value, startDate, endDate) {
                                    _this.timeRange.value = value;
                                    _this.timeRange.start = _this.get_time_stamp(startDate);
                                    _this.timeRange.end = _this.get_time_stamp(endDate);
                                }
                            });
                        },
                        yes: function (layIndex) {
                            var li = '<li class="item other" data-type="6">' + _this.timeRange.value + '</li>';
                            layer.close(layIndex);
                            $this.siblings('.other').remove();
                            $this.siblings('.divider').before(li);
                            $('.bt_select_list .other').click();
                        },
                        btn2: function () {
                            this.cancel();
                        },
                        cancel: function () {
                            var text = $this.parent().find('.item').eq(_this.selectIndex).text();
                            $this.removeClass('active');
                            $this.parent().find('.item').eq(_this.selectIndex).addClass('active');
                            $this.parent().prev().find('.bt_select_content').text('操作时间：' + text);
                        }
                    });
                } else {
                    if (!$this.hasClass('other')) $this.siblings('.other').remove();
                    _this.render_table();
                }
            });
        },
        /**
         * @description 获取日期对象的时间戳
         * @param {object} data 日期对象
         * @return 时间戳
         */
        get_time_stamp: function (data) {
            var date = new Date(data.year, data.month - 1, data.date, data.hours, data.minutes, data.seconds);
            return Math.floor(date.getTime() / 1000);
        },
        /**
         * @description 生成事件id查询框及事件
         * @return void
         */
        render_tools_top_event: function () {
			var that = this
            var html = '\
                <div class="bt_search">\
                    <input type="text" class="search_input" placeholder="搜所有字段" />\
                    <span class="glyphicon glyphicon-search search_btn" aria-hidden="true"></span>\
                </div>\
            ';
			console.log()
			var _el = that.set_el(that.get_menu_index())
            $('#'+ _el +' .tools_top').append(html);
			$('#'+ _el +' .search_input').val('')
            $('#'+ _el +' .search_input').keydown(function (e) {
                if (e.keyCode == 13) {
                    $('#'+ _el +' .search_btn').click();
                }
            });
            $('#'+ _el +' .search_btn').click(function () {
				that.p = 1
                that.render_table();
            });
        },
        get_menu_index: function () {
            return $('#logAudit .tab-nav-border span.on').index();
        },
        /**
         * @description 生成表格
         * @return void
         */
        render_table: function () {
            var _this = this;
            var data = {};
            this.set_search_data(data);
            this.get_event_logs(data, function (res) {
                var _el = _this.get_table_id();
                $(_el).empty();
                var column = _this.get_table_column();
                var table = bt_tools.table({
                    el: _el,
                    data: res,
                    height: $(window).height() - 330+'px',
                    default: '列表为空',
                    column: column
                });
                _this.table_dblclick(table);
				$(_el).next().find('.page_select_number').prevAll().remove()
				$(_el).next().find('.page').prepend(_this.renderPages($(_el).next().find('.page_select_number').val(),_this.p,res.length))
				$(_el).next().find('.nextPage').click(function () {
					_this.p = $(this).data('page')
					_this.render_table();
				})
            });
        },
		/**
		 * @description 渲染日志分页
		 * @param pages
		 * @param p
		 * @param num
		 * @returns {string}
		 */
		renderPages:function(pages,p,num){
			return (p > 1 ?'<a class="nextPage" data-page="1">首页</a>':'') + (p !== 1?'<a class="nextPage" data-page="'+ (p-1) +'">上一页</a>':'') + (pages <= num ? '<a class="nextPage" data-page="'+ (p+1) +'">下一页</a>':'')+'<span class="Pcount">第 '+ p +' 页</span>';
		},
        /**
         * @description 通过tabs获取相对应的表格id
         * @return 表格id
         */
        get_table_id: function () {
            var index = this.get_menu_index(),_id = ''
			switch (index) {
				case 0:
					_id = '#bt_app_table';
					break;
				case 1:
					_id = '#bt_safe_table';
					break;
				case 2:
					_id = '#bt_system_table';
					break;
				case 3:
					_id = '#bt_setup_table';
					break;
				case 4:
					_id = '#bt_fe_table';
					break;
			}
            return _id;
        },
        /**
         * @description 获取表格渲染列
         * @return 表格渲染列
         */
        get_table_column: function () {
			var that = this
            var event = this.get_menu_index()
            var column = [
                { fid: 'Event ID', title: '事件ID', align: 'right' },
                { fid: 'Task', title: '任务类别' },
                { fid: 'Source', title: '来源' },
                { fid: 'Date', title: '操作时间' },
                {
                    title: '操作',
                    type: 'group',
                    width: 100,
                    align: 'right',
                    group: [
                        {
                            title: '详细',
                            event: function (row, index, ev, key, _that) {
                                that.open_windows_details(row);
                            }
                        }
                    ]
                }
            ];
            if (event == 1) {
                column.unshift({
                    fid: 'Keyword',
                    title: '关键字',
                    template: function (row, index) {
                        if (row.Keyword == '审核成功') return '<span>审核成功</span>';
                        if (row.Keyword == '审核失败') return '<span class="bt_danger">审核失败</span>';
                        return '';
                    }
                });
            } else {
                column.unshift({
                    fid: 'Level',
                    title: '级别',
                    template: function (row, index) {
                        if (row.Level == 1) return '<span>关键</span>';
                        if (row.Level == 2) return '<span class="bt_danger">错误</span>';
                        if (row.Level == 3) return '<span class="bt_warning">警告</span>';
                        if (row.Level == 4) return '<span>信息</span>';
                        return '';
                    }
                });
            }
            return column;
        },
		//当前id
		set_el:  function (index) {
            // event
			var _el = ''
			switch (index) {
				case 0:
					_el = 'logApplication';
					break;
				case 1:
					_el = 'logSecurity';
					break;
				case 2:
					_el = 'logSystem';
					break;
				case 3:
					_el = 'logSetup';
					break;
				case 4:
					_el = 'logForwardedEvents';
					break;
			}
			return _el
		},
        /**
         * @description 填充查询数据
         * @param {object} data 传入数据
         * @return void
         */
        set_search_data: function (data) {
            // event
			var event = ''
			switch (this.get_menu_index()) {
				case 0:
					event = 'Application';
					break;
				case 1:
					event = 'Security';
					break;
				case 2:
					event = 'System';
					break;
				case 3:
					event = 'Setup';
					break;
				case 4:
					event = 'ForwardedEvents';
					break;
			}
            data.event = event;
            // 级别
            var level = [];
            $('#log' + event + ' .checkbox_default').each(function () {
                var input = $(this).find('input');
                if (input.is(':checked')) {
                    level.push(input.val());
                }
            });
            data.level = level.join(',');
            // 事件ID
            var eventId = $('#log'+ event +' .search_input').val();
            data.search = eventId;
            // limit
            var limit = $('#log'+ event +' .page_select_number').val();
            data.count = limit;
			data.p = this.p;
            // 时间
            // var time = this.get_time_data();
            // data.start = time.start;
            // data.end = time.end;
        },
        /**
         * @description 获取开始、结束时间戳
         * @return 时间对象包含开始、结束时间戳
         */
         get_time_data: function () {
            var today = new Date();
            var start = 0;
            var end = Math.floor(today.getTime() / 1000);
            var type = parseInt($('.bt_select_list .active').attr('data-type'));
            if (type === 1) {
                start = end - 2 * 3600;
            } else if (type === 2) {
                start = end - 12 * 3600;
            } else if (type === 3) {
                start = end - 24 * 3600;
            } else if (type === 4) {
                start = end - 7 * 24 * 3600;
            } else if (type === 5) {
                start = end - 30 * 24 * 3600;
            } else if (type === 6) {
                start = this.timeRange.start;
                end = this.timeRange.end;
            } else {
                start = '';
                end = '';
            }
            return { start: start, end: end };
        },
        /**
         * @description 表格单行双击事件
         * @param {object} table 生成表格实例对象
         * @return void
         */
        table_dblclick: function (table) {
            var _this = this;
            $('.bt_table tbody tr').dblclick(function () {
                var index = $(this).index();
                var data = table.data[index];
                _this.open_windows_details(data);
            });
        },
        /**
         * @description 打开详情弹框
         * @param {object} data 事件详情数据
         * @return void
         */
        open_windows_details: function (data) {
            var levelStr = this.get_level_str(data['Level']);
            layer.open({
                type: 1,
                closeBtn: 2,
                title: '事件属性',
                area: ["600px", "600px"],
                shadeClose: false,
                content: '\
                    <div class="bt-property-setting pd15">\
                        <div class="tab-nav">\
                            <span class="on">常规</span>\
                        </div>\
                        <div class="tab-con">\
                            <div class="event_info">\
                                <div class="desc">\
                                    <textarea rows="14" disabled>' + data['Description'] + '</textarea>\
                                </div>\
                                <div class="rows">\
                                    <div class="cols">\
                                        <div class="name">日志名称:</div>\
                                        <div class="value" title="应用程序">应用程序</div>\
                                    </div>\
                                </div>\
                                <div class="rows">\
                                    <div class="cols">\
                                        <div class="name">来源:</div>\
                                        <div class="value" title="' + data['Source'] + '">' + data['Source'] + '</div>\
                                    </div>\
                                    <div class="cols">\
                                        <div class="name">记录时间:</div>\
                                        <div class="value" title="' + data['Date'] + '">' + data['Date'] + '</div>\
                                    </div>\
                                </div>\
                                <div class="rows">\
                                    <div class="cols">\
                                        <div class="name">事件ID:</div>\
                                        <div class="value" title="' + data['Event ID'] + '">' + data['Event ID'] + '</div>\
                                    </div>\
                                    <div class="cols">\
                                        <div class="name">任务类别:</div>\
                                        <div class="value" title="' + data['Task'] + '">' + data['Task'] + '</div>\
                                    </div>\
                                </div>\
                                <div class="rows">\
                                    <div class="cols">\
                                        <div class="name">级别:</div>\
                                        <div class="value" title="' + levelStr + '">' + levelStr + '</div>\
                                    </div>\
                                    <div class="cols">\
                                        <div class="name">关键字:</div>\
                                        <div class="value" title="' + data['Keyword'] + '">' + data['Keyword'] + '</div>\
                                    </div>\
                                </div>\
                                <div class="rows">\
                                    <div class="cols">\
                                        <div class="name">用户:</div>\
                                        <div class="value" title="' + data['User'] + '">' + data['User'] + '</div>\
                                    </div>\
                                    <div class="cols">\
                                        <div class="name">计算机:</div>\
                                        <div class="value" title="' + data['Computer'] + '">' + data['Computer'] + '</div>\
                                    </div>\
                                </div>\
                                <div class="rows">\
                                    <div class="cols">\
                                        <div class="name">操作代码:</div>\
                                        <div class="value" title="' + data['Opcode'] + '">' + data['Opcode'] + '</div>\
                                    </div>\
                                </div>\
                            </div>\
                        </div>\
                    </div>\
                '
            });
        },
        /**
         * @description 获取等级名称
         * @param {number} level 等级
         * @return 等级名称
         */
        get_level_str: function (level) {
            if (level == 1) return '关键';
            if (level == 2) return '错误';
            if (level == 3) return '警告';
            if (level == 4) return '信息';
            return '';
        },
        /**
         * @description 获取日志
         * @param {object} data 传入数据
         * @param {function} callback 回调
         * @return void
         */
        get_event_logs: function (data, callback) {
            this.request({
                tips: '正在获取日志，请稍候...',
                method: 'get_event_logs',
                data: {data: JSON.stringify(data)},
                success: function (res) {
                    if (callback) callback(res);
                }
            });
        },
        /**
         * 请求
         */
        request: function (obj) {
            var loadT = '';
            if (obj.load == undefined) obj.load = 0;
            if (obj.url == undefined) {
                if (obj.plugin_name === undefined && this.plugin_name !== undefined) obj.plugin_name = this.plugin_name;
                if (!obj.plugin_name || !obj.method) {
                    layer.msg('插件类名称，或插件方法名称缺失!', {
                        icon: 2
                    });
                    return false;
                }
            }
            if (obj.load === 0 || obj.tips != '') {
                loadT = layer.msg(obj.tips, {
                    icon: 16,
                    time: 0,
                    shade: 0.3
                });
            } else if (obj.load === 1 || (obj.tips == undefined && obj.load == undefined)) {
                loadT = layer.load();
            }
            $.ajax({
                type: 'POST',
                url: obj.url != undefined ? obj.url : ('/safe/syslog/' + obj.method),
                data: obj.data || {},
                timeout: obj.timeout || 99999999,
                complete: function (res) {
                    if (obj.load === 0 || obj.load === 1) layer.close(loadT);
                },
                success: function (rdata) {
                    if (obj.check) {
                        obj.success(rdata);
                        return false
                    }
                    if (rdata.status === false) {
                        layer.msg(rdata.msg, { icon: 2 });
                        return false;
                    }
                    obj.success(rdata);
                }
            });
        }
	},
	// 面板日志
	logs:{
		/**
		 * @description 事件绑定
		 */
		event:function (){
			var that = this;
			$('.state-content').hide()
			$('#logsBody').unbind('click').on('click','.tab-nav-border span',function(){
			  var index = $(this).index();
			  $(this).addClass('on').siblings().removeClass('on');
			  $(this).parent().next().find('.tab-block').eq(index).addClass('on').siblings().removeClass('on');
			  that.cutLogsTab(index)
			})
			$(window).unbind('resize').resize(function (){
			  $('#errorLog .crontab-log').height((window.innerHeight - 310) +'px')
			})
			$('#logsBody .tab-nav-border span').eq(0).trigger('click');
			$('.refresh_log').unbind('click').on('click',function (){
				that.getLogs(1)
			})
			$('.close_log').unbind('click').on('click',function (){
				that.delLogs()
			})
		},
		/**
		 * @description 切换日志菜单
		 * @param {number} index 索引
		 */
		cutLogsTab:function(index){
			switch (index) {
				case 0:
					this.getLogs(1)
					break;
				case 1:
					this.runLogs()
					break;
				case 2:
					this.errorLog()
					break;
			}
		},
		/**
		 * @description 运行日志
		*/
		runLogs:function (p,limit,search){
			var that = this;
			search = search == undefined ? '':search;
			limit = limit || 20
			p = p || 1
			$('#panelRun').empty()
			bt_tools.table({
				el:'#panelRun',
				url:'/logs/panel/get_panel_log',
				param: {
					data : JSON.stringify({
						p: p,
						limit: limit,
						search: search
					})
				},
				load: '正在获取运行日志，请稍候...',
				height: $(window).height() - 330+'px',
				default: '列表为空', // 数据为空时的默认提示
				dataFilter: function (res) {
					if(!$('#panelRun .page').length){
						$('#panelRun .tootls_top').append('<div class="pull-right">\
								<div class="bt_search">\
									<input type="text" class="search_input" style="" placeholder="搜索日志" value="'+ search +'">\
									<span class="glyphicon glyphicon-search" aria-hidden="true"></span>\
								</div>\
							</div>')
						var html = '\
							<div class="tootls_group tools_bottom">\
								<div class="page">\
									<select class="page_select_number">\
										<option value="20" selected>20条/页</option>\
										<option value="50">50条/页</option>\
										<option value="100">100条/页</option>\
										<option value="500">500条/页</option>\
										<option value="1000">1000条/页</option>\
									</select>\
								</div>\
							</div>\
						';
						$('#panelRun .divtable').after(html)
						var select_num = $('#panelRun .tools_bottom .page_select_number'),search_input = $('#panelRun .search_input')
						select_num.val(limit)
						select_num.change(function () {
							that.runLogs(p, $(this).val())
						});
						$('#panelRun .page').prepend(firewall.logAudit.renderPages(select_num.val(), p, res.length))
						$('#panelRun .page').find('.nextPage').click(function () {
							that.runLogs($(this).data('page'),select_num.val(),search_input.val())
						})
						search_input.keydown(function (e) {
							var value = $(this).val()
							if(e.keyCode == 13) that.runLogs(p,select_num.val(),value)
						})
						$('#panelRun .glyphicon-search').click(function () {
							that.runLogs(p,select_num.val(),$(this).prev().val())
						})
						$('#panelRun .search_input').focus(function () {
							layer.tips("特殊符号不支持搜索，xss类型的符号，如..,'", $(this), { tips: [1, '#bbb'],time: 0});
						})
						$('#panelRun .search_input').blur(function () {
							layer.closeAll('tips');
						})
					}
					return {data: res}
				},
				tootls: [
					{ // 按钮组
						type: 'group',
						positon: ['left', 'top'],
						list: [{
							title: '刷新日志',
							active: true,
							event: function (ev,_that) {
								that.runLogs()
							}
						}]
					}
				],
				column: [
					{ fid: 'date', title: "操作时间",width: 150},
					{ fid: 'ip', title: "IP:端口",width: 130 },
					{ title: "归属地",width: 130,template:function (row){
						return '<span>'+ (row.area?'' + row.area.info + '':'-') +'</span>';
					}},
					{ fid: 'method', title: "请求类型",width: 100 },
					{ fid: 'uri', title: "URI",width: 200 },
					{ fid: 'argv', title: "参数",width: 200},
					{ fid: 'user-agent', title: "浏览器标识",width: 300,fixed: true},
				]
			})
		},
		/**
		 * @description 错误日志
		 */
		 errorLog:function (){
			var that = this;
			bt_tools.send({
				url:'/files?action=GetFileBody'},{path:setup_path+"/panel/data/panelError.log"},function(res){
				log = res.data
				if(res.data == '') log = '当前没有日志'
				$('#errorLog').html('<div style="font-size: 0;">\
					<button type="button" title="刷新日志" class="btn btn-success btn-sm mr5 refreshRunLogs" ><span>刷新日志</span></button>\
					<pre class="crontab-log">'+ log +'</pre>\
				</div>');
				$('.refreshRunLogs').click(function (){
					that.errorLog()
				})
				$('#errorLog .crontab-log').height((window.innerHeight - 310) +'px')
				var div = document.getElementsByClassName('crontab-log')[0]
				div.scrollTop = div.scrollHeight;
			},'面板错误日志')
		},
		/**
		* 取回数据
		* @param {Int} page  分页号
		*/
		getLogs:function(page,search) {
			var that = this
			search = search == undefined ? '':search;
			bt_tools.send({url:'/data?action=getData&table=logs&tojs=getLogs&limit=20&p=' + page+"&search="+search}, function(data) {
				$('#operationLog').empty()
				bt_tools.table({
					el:'#operationLog',
					data: data.data,
                    height: $(window).height() - 330+'px',
                    default: '操作列表为空', // 数据为空时的默认提示
					tootls: [
						{ // 按钮组
							type: 'group',
							positon: ['left', 'top'],
							list: [{
								title: '刷新日志',
								active: true,
								event: function (ev,_that) {
									that.getLogs(1)
								}
							}, {
								title: '清空日志',
								event: function (ev,_that) {
									that.delLogs()
								}
							}]
						}
					],
					column:[
						{ fid: 'username', title: "用户",width: 100 },
						{ fid: 'type', title: "操作类型",width: 100 },
						{ fid: 'log', title: "详情"},
						{ fid: 'addtime', title: "操作时间",width: 150}
					],
					success: function () {
						if(!$('.search_input').length){
							$('#operationLog .tootls_top').append('<div class="pull-right">\
								<div class="bt_search">\
									<input type="text" class="search_input" style="" placeholder="搜索日志" value="'+ search +'">\
									<span class="glyphicon glyphicon-search" aria-hidden="true"></span>\
								</div>\
							</div>')
							$('.search_input').keydown(function (e) {
								var value = $(this).val()
								if(e.keyCode == 13) that.getLogs(1,value)
							})
							$('.glyphicon-search').click(function () {
								var value = $('.search_input').val()
								that.getLogs(1,value)
							})
						}
					}
				})
				$('.operationLog').html(data.page);
			},'获取面板操作日志')
		},
		//清理面板日志
		delLogs: function(){
			var that = this
			layer.confirm(lan.firewall.close_log_msg,{title:lan.firewall.close_log,closeBtn:2},function(){
				var loadT = layer.msg(lan.firewall.close_the,{icon:16});
				bt_tools.send('/ajax?action=delClose',function(rdata){
					layer.close(loadT);
					layer.msg(rdata.msg,{icon:rdata.status?1:2});
					that.getLogs(1);
				});
			});
		},
	},
	/**
		 * @description 渲染日志分页
		 * @param pages
		 * @param p
		 * @param num
		 * @returns {string}
		 */
	 renderLogsPages:function(pages,p,num){
		return (num >= pages?'<a class="nextPage" data-page="1">首页</a>':'') + (p !== 1?'<a class="nextPage" data-page="'+ (p-1) +'">上一页</a>':'') + (pages <= num?'<a class="nextPage" data-page="'+ (p+1) +'">下一页</a>':'')+'<span class="Pcount">第 '+ p +' 页</span>';
	}
}

firewall.event();

//面板操作日志分页切换
function getLogs(page) {
	firewall.logs.getLogs(page,$('#operationLog .search_input').val())
}